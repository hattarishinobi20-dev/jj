import sys
sys.dont_write_bytecode = True
import socket
import time
import os
import sqlite3
import subprocess
subprocess.Popen(['python', 'quests.py'])

import json
from threading import Thread
from database.DataBase import DataBase
from Logic.Device import Device
from Logic.Player import Players
from Logic.LogicMessageFactory import packets
from Utils.Config import Config
from Utils.Helpers import Helpers
from shared import connected_ips

#IMPORTANT INFO;
from SupercellLaserServerInfo.information import infolator

def log_info(*args):
    print('[INFO]', *args)

class Server:
    Clients = {"ClientCounts": 0, "Clients": {}}

    def __init__(self, ip: str, port: int):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.port = port
        self.ip = ip
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind((self.ip, self.port))
        log_info(f'The lobby started! {self.ip}:{self.port}')
        try:
            from websites import start_websites
            start_websites()
        except Exception:
            pass
        self.clear_connected_ips()
        self.setup_database()
        self.total_sent_bytes = 0
        self.total_received_bytes = 0

        Thread(target=self.clean_database_periodically, daemon=True).start()
        Thread(target=self.ensure_start_py_running, daemon=True).start()

    def setup_database(self):
        if os.path.exists("database/Player/plr.db"):
            with sqlite3.connect("database/Player/plr.db") as conn:
                c = conn.cursor()
                c.execute(""" 
                    CREATE TABLE IF NOT EXISTS plrs (
                        token TEXT, lowID INT, name TEXT, trophies INT, gold INT, gems INT, 
                        starpoints INT, tickets INT, Troproad INT, profile_icon INT, 
                        name_color INT, clubID INT, clubRole INT, brawlerData JSON, 
                        brawlerID INT, skinID INT, roomID INT, box INT, bigbox INT, 
                        online INT, vip INT, playerExp INT, friends JSON, SCC TEXT, 
                        trioWINS INT, sdWINS INT, theme INT, BPTOKEN INT, BPXP INT, 
                        quests JSON, freepass INT, buypass INT, notifRead INT, notifRead2 INT,
                        ip_address TEXT, creation_date TEXT, Region TEXT, winstreak INT, highestwinstreak INT,
                        notifs JSON, lastonline INT
                    )
                """)
                c.execute("UPDATE plrs SET roomID=0")
                c.execute("UPDATE plrs SET online=0")
                conn.commit()
        else:
            with sqlite3.connect("database/Player/plr.db") as conn:
                c = conn.cursor()
                c.execute(""" 
                    CREATE TABLE IF NOT EXISTS plrs (
                        token TEXT, lowID INT, name TEXT, trophies INT, gold INT, gems INT, 
                        starpoints INT, tickets INT, Troproad INT, profile_icon INT, 
                        name_color INT, clubID INT, clubRole INT, brawlerData JSON, 
                        brawlerID INT, skinID INT, roomID INT, box INT, bigbox INT, 
                        online INT, vip INT, playerExp INT, friends JSON, SCC TEXT, 
                        trioWINS INT, sdWINS INT, theme INT, BPTOKEN INT, BPXP INT, 
                        quests JSON, freepass INT, buypass INT, notifRead INT, notifRead2 INT,
                        ip_address TEXT, creation_date TEXT, Region TEXT, winstreak INT, highestwinstreak INT,
                        notifs JSON, lastonline INT
                    )
                """)
                conn.commit()

    def clean_database_periodically(self):
        while True:
            time.sleep(3600)
            try:
                with sqlite3.connect("database/Player/plr.db") as conn:
                    c = conn.cursor()
                    c.execute("DELETE FROM plrs WHERE gold=100 AND trioWINS=0 AND trophies > 0")
                    log_info("The database has been cleared of bots")
                    conn.commit()
            except Exception as e:
                log_info(f"Error clearing database: {e}")

    def ensure_start_py_running(self):
        """Ensure start.py is always running."""
        while True:
            try:
                process = subprocess.Popen(['python', 'start.py'])
                process.wait()
                print("[INFO] start.py durdu, yeniden başlatılıyor...")
            except Exception as e:
                print(f"[ERROR] start.py çalıştırılamadı: {e}")
            time.sleep(5)

    def start(self):
        while True:
            self.server.listen()
            try:
                client, address = self.server.accept()
            except Exception as e:
                log_info(f"Error connection: {e}")
                continue

            self.log_connection(address[0])
            connected_ips.add(address[0])
            ClientThread(client, address, self).start()

    def clear_connected_ips(self):
        with open('JSON/ConnectedIP.json', 'w') as log_file:
            json.dump([], log_file, indent=4)
        log_info("The ConnectedIP.json file was cleared when the server started")

    def log_connection(self, ip):
        moscow_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + 3 * 3600))  # UTC+3 для Москвы
        with sqlite3.connect("database/Player/plr.db") as conn:
            c = conn.cursor()
            c.execute("SELECT lowID, name FROM plrs WHERE SCC = ?", (ip,))
            result = c.fetchone()

        log_data = {
            "time": moscow_time,
            "ip": ip
        }

        with open('JSON/ConnectedIP.json', 'a') as log_file:
            json.dump(log_data, log_file, ensure_ascii=False, indent=4)
            log_file.write('\n')

        log_info(f"Connection: {log_data}")

class ClientThread(Thread):
    def __init__(self, client, address, server):
        super().__init__()
        self.client = client
        self.address = address
        self.device = Device(self.client)
        self.player = Players(self.device)
        self.server = server
        self.total_received_bytes = 0
        self.total_sent_bytes = 0
        self.last_packet_time = time.time()

    def recvall(self, length):
        data = b''
        while len(data) < length:
            packet = self.client.recv(length - len(data))
            if not packet:
                break
            data += packet
        return data

    def run(self):
        client_ip = self.address[0]
        try:
            client_ip = self.client.getpeername()[0]
            self.player.ip_address = self.client.getpeername()[0]
            while True:
                header = self.client.recv(7)
                if len(header) > 0:
                    packet_id = int.from_bytes(header[:2], 'big')
                    length = int.from_bytes(header[2:5], 'big')
                    data = self.recvall(length)

                    self.total_received_bytes += length
                    self.server.total_sent_bytes += length

                    if packet_id in packets:
                        message = packets[packet_id](self.client, self.player, data)
                        message.decode()
                        message.process()
                else:
                    break
        except Exception as e:
            log_info(f"[ERROR] The client has an error. - {client_ip}: {e}")
        finally:
            self.client.close()
            connected_ips.discard(client_ip)
            log_info(f"[INFO] IP {client_ip} Left")
            DataBase.replaceValue(self, "lastonline", int(time.time()))

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    try:
        from websites import start_websites
        start_websites()
        log_info("Sites: store 8080 | lookup 8081 | panel 8082 | voucher 8083 | event 8084")
    except Exception as e:
        log_info("Sites failed: %s" % e)
    server = Server("0.0.0.0", 9449)
    server.start()
