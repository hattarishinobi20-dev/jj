const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const state = {
  user: window.__STORE_USER__ || null,
  cart: JSON.parse(localStorage.getItem("sc_cart") || "[]").map((i) => ({
    ...i,
    kind: i.kind || "gems",
    amount: Number(i.amount || i.gems || 0),
  })),
};

function saveCart() {
  localStorage.setItem("sc_cart", JSON.stringify(state.cart));
  renderCart();
}

function cartCount() {
  return state.cart.reduce((n, i) => n + i.qty, 0);
}

function cartGems() {
  return state.cart.reduce((n, i) => n + i.gems * i.qty, 0);
}

function toast(msg) {
  const el = $("#toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 2400);
}

function applyUser() {
  const u = state.user;
  $("#heroGuest").hidden = !!u;
  $("#heroUser").hidden = !u;
  const av = $("#avatar");
  const profile = $("#profileBtn");
  if (u) {
    $("#userName").textContent = u.name;
    $("#userId").textContent = u.low_id;
    $("#userGems").textContent = u.gems;
    if ($("#userGold")) $("#userGold").textContent = u.gold || 0;
    av.textContent = (u.name || "?").trim().charAt(0).toUpperCase();
    av.classList.add("logged");
    profile.removeAttribute("href");
    profile.title = `${u.name} · ID ${u.low_id}`;
    if ($("#menuAccount")) $("#menuAccount").hidden = false;
    $("#menuLogin").hidden = true;
    $("#menuLogout").hidden = false;
  } else {
    av.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.4" stroke="currentColor" stroke-width="1.7"/><path d="M5.2 19.2c.7-3.4 3.4-5.2 6.8-5.2s6.1 1.8 6.8 5.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>`;
    av.classList.remove("logged");
    profile.setAttribute("href", "/login");
    $("#menuLogin").hidden = false;
    $("#menuLogout").hidden = true;
  }
}

function renderCart() {
  $("#cartBtn").dataset.count = String(cartCount());
  const body = $("#cartBody");
  const foot = $("#cartFoot");
  if (!state.cart.length) {
    body.innerHTML = `<p class="cart-empty">Your bag is empty.</p>`;
    foot.hidden = true;
    return;
  }
  foot.hidden = false;
  body.innerHTML = state.cart.map((item) => `
    <div class="line" data-id="${item.id}">
      <img src="${item.kind === "coins" ? "/static/img/coins.png" : "/static/img/bs_preview_static_gems-3VNCDZKE.png"}" alt=""/>
      <div>
        <b>${item.name}</b>
        <div class="qty">
          <button type="button" data-act="dec">−</button>
          <span>${item.qty}</span>
          <button type="button" data-act="inc">+</button>
          <button type="button" class="remove" data-act="rm">Remove</button>
        </div>
      </div>
      <div><b>${item.amount * item.qty}</b></div>
    </div>
  `).join("");
  $("#cartTotal").textContent = cartSummary();
}

function cartSummary() {
  const gems = state.cart.filter((i) => i.kind === "gems").reduce((n, i) => n + i.amount * i.qty, 0);
  const coins = state.cart.filter((i) => i.kind === "coins").reduce((n, i) => n + i.amount * i.qty, 0);
  const parts = [];
  if (gems) parts.push(`${gems} gems`);
  if (coins) parts.push(`${coins} coins`);
  return parts.join(" + ") || "0";
}

function addToCart(pack) {
  const found = state.cart.find((i) => i.id === pack.id);
  if (found) found.qty += 1;
  else state.cart.push({ id: pack.id, name: pack.name, kind: pack.kind, amount: pack.amount, qty: 1 });
  saveCart();
  openCart();
}

function openCart() {
  $("#cart").classList.add("open");
  $("#cartScrim").classList.add("show");
  $("#cart").setAttribute("aria-hidden", "false");
}
function closeCart() {
  $("#cart").classList.remove("open");
  $("#cartScrim").classList.remove("show");
  $("#cart").setAttribute("aria-hidden", "true");
}

$$(".add-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const card = btn.closest(".pack");
    addToCart({
      id: card.dataset.id,
      name: card.dataset.name,
      kind: card.dataset.kind || "gems",
      amount: Number(card.dataset.amount || card.dataset.gems || 0),
    });
  });
});

$("#cartBody").addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  const id = btn.closest(".line").dataset.id;
  const item = state.cart.find((i) => i.id === id);
  if (!item) return;
  if (btn.dataset.act === "inc") item.qty += 1;
  if (btn.dataset.act === "dec") item.qty = Math.max(1, item.qty - 1);
  if (btn.dataset.act === "rm") state.cart = state.cart.filter((i) => i.id !== id);
  saveCart();
});

$("#cartBtn").addEventListener("click", openCart);
$("#closeCart").addEventListener("click", closeCart);
$("#cartScrim").addEventListener("click", closeCart);

$("#menuBtn").addEventListener("click", () => {
  $("#sideMenu").classList.add("open");
  $("#menuScrim").classList.add("show");
});
$("#closeMenu").addEventListener("click", closeMenu);
$("#menuScrim").addEventListener("click", closeMenu);
function closeMenu() {
  $("#sideMenu").classList.remove("open");
  $("#menuScrim").classList.remove("show");
}

$("#profileBtn").addEventListener("click", (e) => {
  if (!state.user) return;
  e.preventDefault();
  document.getElementById("gems").scrollIntoView({ behavior: "smooth" });
});

$("#menuLogout").addEventListener("click", logout);

async function logout() {
  await fetch("/api/logout", { method: "POST" });
  state.user = null;
  applyUser();
  closeMenu();
  toast("Logged out");
}

$("#checkoutBtn").addEventListener("click", async () => {
  if (!state.user) {
    location.href = "/login";
    return;
  }
  if (!state.cart.length) return;
  const btn = $("#checkoutBtn");
  btn.disabled = true;
  btn.textContent = "Processing...";
  try {
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items: state.cart.map(({ id, qty }) => ({ id, qty })) }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      toast(data.error || "Could not complete the purchase.");
      if (res.status === 401) location.href = "/login";
      return;
    }
    state.cart = [];
    saveCart();
    applyUser();
    closeCart();
    $("#okText").textContent = `${data.summary || "Your rewards"} are waiting for Low ID ${state.user.low_id}. Open the game inbox and claim them.`;
    $("#okModal").hidden = false;
  } catch (err) {
    toast("Could not reach the store.");
  } finally {
    btn.disabled = false;
    btn.textContent = "Complete purchase";
  }
});

$("#okClose").addEventListener("click", () => {
  $("#okModal").hidden = true;
});

applyUser();
renderCart();

async function loadSkinOffers() {
  const box = document.getElementById("skinOffers");
  if (!box) return;
  try {
    const res = await fetch("/api/offers");
    const data = await res.json();
    const offers = (data.offers || []).filter((o) => o.active);
    if (!offers.length) {
      box.innerHTML = `<p class="skin-empty">No skin offers right now.</p>`;
      return;
    }
    box.innerHTML = offers.map((o) => {
      const art = o.photo
        ? `<img class="pack-art" src="${o.photo}" alt="${o.name}"/>`
        : `<img class="pack-art" src="/static/img/store_bag.png" alt="${o.name}"/>`;
      const old = o.discount ? `<span class="price-old">${o.old_gems}</span>` : "";
      const tag = o.discount ? `<span class="pack-tag disc">DISCOUNT</span>` : `<span class="pack-tag">SKIN</span>`;
      return `<article class="pack skin-pack" data-offer="${o.id}" style="background:${o.background}">
        ${tag}
        <h3>${o.name}</h3>
        <div class="pack-brawler">${o.brawler || ""}</div>
        ${art}
        <div class="price-row">${old}<div class="pack-amt">${o.gems}</div></div>
        <button class="add-btn buy-skin" type="button">Buy · ${o.gems} gems</button>
      </article>`;
    }).join("");
  } catch (err) {
    box.innerHTML = `<p class="skin-empty">Offers are unavailable.</p>`;
  }
}

document.getElementById("skinOffers")?.addEventListener("click", async (e) => {
  const btn = e.target.closest(".buy-skin");
  if (!btn) return;
  if (!state.user) {
    location.href = "/login";
    return;
  }
  const card = btn.closest("[data-offer]");
  const id = Number(card.dataset.offer);
  btn.disabled = true;
  try {
    const res = await fetch("/api/buy-offer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      toast(data.error || "Could not buy this offer.");
      if (res.status === 401) location.href = "/login";
      return;
    }
    if (typeof data.gems === "number") {
      state.user.gems = data.gems;
      applyUser();
    }
    $("#okText").textContent = data.message || "The skin is on your account.";
    $("#okModal").hidden = false;
  } catch (err) {
    toast("Could not reach the store.");
  } finally {
    btn.disabled = false;
  }
});

loadSkinOffers();
