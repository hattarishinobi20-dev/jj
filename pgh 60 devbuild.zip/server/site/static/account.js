const $ = (s) => document.querySelector(s);
const kind = $("#kind");
const gemsField = $("#gemsField");
const coinsField = $("#coinsField");
const gemsLabel = gemsField.querySelector("label");

function syncFields() {
  const v = kind.value;
  gemsField.hidden = v === "coins";
  coinsField.hidden = v === "gems";
  gemsLabel.textContent = v === "both" ? "Gems amount" : (v === "gems" ? "Gems amount" : "Gems amount");
}
kind.addEventListener("change", syncFields);
syncFields();

$("#menuBtn").addEventListener("click", () => {
  $("#sideMenu").classList.add("open");
  $("#menuScrim").classList.add("show");
});
function closeMenu() {
  $("#sideMenu").classList.remove("open");
  $("#menuScrim").classList.remove("show");
}
$("#closeMenu").addEventListener("click", closeMenu);
$("#menuScrim").addEventListener("click", closeMenu);
$("#menuLogout").addEventListener("click", async () => {
  await fetch("/api/logout", { method: "POST" });
  location.href = "/";
});

$("#transferForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const err = $("#formError");
  const ok = $("#formOk");
  err.hidden = true;
  ok.hidden = true;
  const btn = $("#sendBtn");
  btn.disabled = true;
  btn.textContent = "Sending...";
  const payload = {
    low_id: $("#targetId").value.trim(),
    gems: 0,
    coins: 0,
  };
  if (kind.value === "gems" || kind.value === "both") {
    payload.gems = Number($("#gemsAmt").value || 0);
  }
  if (kind.value === "coins" || kind.value === "both") {
    payload.coins = Number($("#coinsAmt").value || 0);
  }
  try {
    const res = await fetch("/api/transfer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      err.textContent = data.error || "Could not send resources.";
      err.hidden = false;
      return;
    }
    ok.textContent = data.message || "The resources were sent to that account.";
    ok.hidden = false;
    $("#gemsAmt").value = "";
    $("#coinsAmt").value = "";
  } catch (ex) {
    err.textContent = "Could not reach the store.";
    err.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = "Send resources";
  }
});
