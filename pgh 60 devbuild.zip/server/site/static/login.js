const form = document.getElementById("loginForm");
const input = document.getElementById("lowId");
const error = document.getElementById("error");
const btn = document.getElementById("submitBtn");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  error.hidden = true;
  const lowId = input.value.trim();
  if (!lowId) {
    error.textContent = "Enter your account Low ID.";
    error.hidden = false;
    return;
  }
  btn.disabled = true;
  btn.textContent = "Logging in...";
  try {
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ low_id: lowId }),
    });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      error.textContent = data.error || "Could not log in.";
      error.hidden = false;
      return;
    }
    location.href = "/";
  } catch (err) {
    error.textContent = "Something went wrong. Please try again later.";
    error.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = "Continue";
  }
});
