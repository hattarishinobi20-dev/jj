import os
import sys
import json
import random
import time
import sqlite3
import secrets
import logging
import traceback
from datetime import datetime, timedelta
from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
)
from werkzeug.exceptions import HTTPException

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(ROOT, "database", "Player", "plr.db")
ERROR_FILE = os.path.join(ROOT, "site_errors.txt")
sys.path.insert(0, ROOT)
import offers_store

logging.getLogger("werkzeug").disabled = True
logging.getLogger("werkzeug").setLevel(logging.CRITICAL)


def write_error(err):
    try:
        with open(ERROR_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {err}\n")
            f.write(traceback.format_exc())
            f.write("\n")
    except Exception:
        pass

PACKS = {
    "gems-100": {"id": "gems-100", "name": "100 Gems", "kind": "gems", "amount": 100},
    "gems-200": {"id": "gems-200", "name": "200 Gems", "kind": "gems", "amount": 200},
    "gems-5000": {"id": "gems-5000", "name": "5000 Gems", "kind": "gems", "amount": 5000},
    "coins-1000": {"id": "coins-1000", "name": "1000 Coins", "kind": "coins", "amount": 1000},
    "coins-5000": {"id": "coins-5000", "name": "5000 Coins", "kind": "coins", "amount": 5000},
    "coins-20000": {"id": "coins-20000", "name": "20000 Coins", "kind": "coins", "amount": 20000},
}

app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(__file__), "templates"),
    static_folder=os.path.join(os.path.dirname(__file__), "static"),
)
app.secret_key = os.environ.get("STORE_SECRET", "pgh-brawl-store-secret")
app.logger.disabled = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=365)
app.config["JSON_AS_ASCII"] = False


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def find_player(low_id):
    try:
        low_id = int(str(low_id).strip().lstrip("#"))
    except (TypeError, ValueError):
        return None
    if low_id < 2:
        return None
    if not os.path.exists(DB_PATH):
        return None
    conn = db()
    try:
        row = conn.execute(
            "SELECT lowID, name, gems, gold, trophies, profile_icon FROM plrs WHERE lowID = ?",
            (low_id,),
        ).fetchone()
        if not row:
            return None
        return {
            "low_id": int(row["lowID"]),
            "name": row["name"] or "Player",
            "gems": int(row["gems"] or 0),
            "gold": int(row["gold"] or 0),
            "trophies": int(row["trophies"] or 0),
            "icon": int(row["profile_icon"] or 0),
        }
    finally:
        conn.close()


def current_user():
    low_id = session.get("low_id")
    if not low_id:
        return None
    return find_player(low_id)


def add_reward_notification(low_id, kind, amount, msg=None):
    conn = db()
    try:
        row = conn.execute("SELECT notifs FROM plrs WHERE lowID = ?", (low_id,)).fetchone()
        if not row:
            return False
        try:
            notifs = json.loads(row["notifs"]) if row["notifs"] else []
        except Exception:
            notifs = []
        if not isinstance(notifs, list):
            notifs = []
        label = "gems" if kind == "gems" else "coins"
        item = {
            "ID": 89 if kind == "gems" else 81,
            "index": random.randint(1, 999999999),
            "seen": False,
            "ago": int(time.time()),
            "msg": msg or f"Thank you for buying {int(amount)} {label} on our site",
            "msg_TYPE": 1,
        }
        if kind == "gems":
            item["gems"] = int(amount)
        else:
            item["gold"] = int(amount)
        notifs.append(item)
        conn.execute("UPDATE plrs SET notifs = ? WHERE lowID = ?", (json.dumps(notifs), low_id))
        conn.commit()
        return True
    finally:
        conn.close()


@app.after_request
def no_cache_html(resp):
    if request.path in ("/", "/login", "/account", "/pt/brawlstars") or request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/")
@app.route("/pt/brawlstars")
@app.route("/brawlstars")
def store():
    return render_template("store.html", user=current_user())


@app.route("/login")
@app.route("/accounts/login")
def login_page():
    if current_user():
        return redirect("/")
    return render_template("login.html")


@app.route("/account")
def account_page():
    user = current_user()
    if not user:
        return redirect("/login")
    return render_template("account.html", user=user)


@app.route("/api/me")
def api_me():
    user = current_user()
    if not user:
        return jsonify({"ok": False, "user": None})
    return jsonify({"ok": True, "user": user})


@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json(silent=True) or {}
    low_id = data.get("low_id") or data.get("email") or data.get("id")
    player = find_player(low_id)
    if not player:
        return jsonify({"ok": False, "error": "Account not found. Check your Low ID."}), 404
    session.permanent = True
    session["low_id"] = player["low_id"]
    session["sid"] = secrets.token_hex(8)
    return jsonify({"ok": True, "user": player})


@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/transfer", methods=["POST"])
def api_transfer():
    user = current_user()
    if not user:
        return jsonify({"ok": False, "error": "Log in to transfer resources."}), 401

    data = request.get_json(silent=True) or {}
    target = find_player(data.get("low_id"))
    if not target:
        return jsonify({"ok": False, "error": "That Low ID was not found."}), 404
    if int(target["low_id"]) == int(user["low_id"]):
        return jsonify({"ok": False, "error": "You cannot send resources to yourself."}), 400

    try:
        gems = int(data.get("gems") or 0)
        coins = int(data.get("coins") or 0)
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Invalid amount."}), 400

    if gems < 0 or coins < 0 or (gems == 0 and coins == 0):
        return jsonify({"ok": False, "error": "Enter an amount to send."}), 400

    conn = db()
    try:
        row = conn.execute(
            "SELECT gems, gold FROM plrs WHERE lowID = ?",
            (user["low_id"],),
        ).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "Account not found."}), 404
        have_gems = int(row["gems"] or 0)
        have_gold = int(row["gold"] or 0)
        if gems > have_gems:
            return jsonify({"ok": False, "error": "Not enough gems on your account."}), 400
        if coins > have_gold:
            return jsonify({"ok": False, "error": "Not enough coins on your account."}), 400
        conn.execute(
            "UPDATE plrs SET gems = ?, gold = ? WHERE lowID = ?",
            (have_gems - gems, have_gold - coins, user["low_id"]),
        )
        conn.commit()
    finally:
        conn.close()

    sender = user["name"] or "A player"
    if gems > 0:
        add_reward_notification(
            target["low_id"],
            "gems",
            gems,
            msg=f"{sender} sent you {gems} gems",
        )
    if coins > 0:
        add_reward_notification(
            target["low_id"],
            "coins",
            coins,
            msg=f"{sender} sent you {coins} coins",
        )

    return jsonify({
        "ok": True,
        "message": "The resources were sent to that account.",
    })


@app.route("/api/checkout", methods=["POST"])
def api_checkout():
    user = current_user()
    if not user:
        return jsonify({"ok": False, "error": "Log in to complete your purchase."}), 401

    data = request.get_json(silent=True) or {}
    items = data.get("items") or []
    totals = {"gems": 0, "coins": 0}
    parsed = []
    for item in items:
        pack = PACKS.get(str(item.get("id", "")))
        if not pack:
            return jsonify({"ok": False, "error": "Invalid item in the bag."}), 400
        try:
            qty = int(item.get("qty", 1))
        except (TypeError, ValueError):
            qty = 0
        if qty < 1 or qty > 99:
            return jsonify({"ok": False, "error": "Invalid quantity."}), 400
        amount = pack["amount"] * qty
        totals[pack["kind"]] = totals.get(pack["kind"], 0) + amount
        parsed.append({"name": pack["name"], "qty": qty, "kind": pack["kind"], "amount": amount})

    if totals["gems"] <= 0 and totals["coins"] <= 0:
        return jsonify({"ok": False, "error": "Your bag is empty."}), 400

    if totals["gems"] > 0 and not add_reward_notification(user["low_id"], "gems", totals["gems"]):
        return jsonify({"ok": False, "error": "Account not found."}), 404
    if totals["coins"] > 0 and not add_reward_notification(user["low_id"], "coins", totals["coins"]):
        return jsonify({"ok": False, "error": "Account not found."}), 404

    parts = []
    if totals["gems"]:
        parts.append(f"{totals['gems']} gems")
    if totals["coins"]:
        parts.append(f"{totals['coins']} coins")
    summary = " + ".join(parts)

    return jsonify({
        "ok": True,
        "gems_added": totals["gems"],
        "coins_added": totals["coins"],
        "summary": summary,
        "items": parsed,
        "message": "Purchase confirmed! Open the game inbox and claim your rewards.",
    })


@app.route("/api/offers")
def api_offers():
    return jsonify({"ok": True, "offers": offers_store.list_offers(active_only=True)})


def grant_skin(low_id, skin_id, brawler_id, name, gems_cost):
    conn = db()
    try:
        row = conn.execute(
            "SELECT gems, brawlerData, notifs FROM plrs WHERE lowID = ?",
            (low_id,),
        ).fetchone()
        if not row:
            return False, "Account not found."
        have = int(row["gems"] or 0)
        cost = int(gems_cost or 0)
        if cost < 0:
            return False, "Invalid price."
        if have < cost:
            return False, "Not enough gems on your account."
        try:
            bd = json.loads(row["brawlerData"] or "{}")
        except Exception:
            bd = {}
        skins = bd.get("UnlockedSkins") or {}
        if int(skins.get(str(skin_id), skins.get(skin_id, 0)) or 0) == 1:
            return False, "You already own this skin."
        skins[str(int(skin_id))] = 1
        bd["UnlockedSkins"] = skins
        unlocked = bd.get("UnlockedBrawlers") or {}
        unlocked[str(int(brawler_id))] = 1
        bd["UnlockedBrawlers"] = unlocked
        try:
            notifs = json.loads(row["notifs"] or "[]")
        except Exception:
            notifs = []
        if not isinstance(notifs, list):
            notifs = []
        notifs.append({
            "ID": 94,
            "index": random.randint(1, 999999999),
            "seen": False,
            "ago": int(time.time()),
            "msg": f"Thank you for buying {name} on our site",
            "msg_TYPE": 1,
            "skin_id": int(skin_id),
        })
        conn.execute(
            "UPDATE plrs SET gems = ?, brawlerData = ?, notifs = ? WHERE lowID = ?",
            (have - cost, json.dumps(bd), json.dumps(notifs), low_id),
        )
        conn.commit()
        return True, have - cost
    finally:
        conn.close()


@app.route("/api/buy-offer", methods=["POST"])
def api_buy_offer():
    user = current_user()
    if not user:
        return jsonify({"ok": False, "error": "Log in to complete your purchase."}), 401
    data = request.get_json(silent=True) or {}
    try:
        oid = int(data.get("id"))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Invalid offer."}), 400
    offer = offers_store.get_offer(oid)
    if not offer or not offer.get("active", True):
        return jsonify({"ok": False, "error": "That offer is not available."}), 404
    ok, extra = grant_skin(
        user["low_id"],
        offer.get("skin_id") or 0,
        offer.get("brawler_id") or 0,
        offer.get("name") or "Skin",
        offer.get("gems") or 0,
    )
    if not ok:
        return jsonify({"ok": False, "error": extra}), 400
    return jsonify({
        "ok": True,
        "gems": extra,
        "message": "Purchase confirmed! The skin is on your account. Open the game inbox to claim it.",
    })


@app.errorhandler(Exception)
def on_error(err):
    if isinstance(err, HTTPException):
        return err
    write_error(err)
    return jsonify({"ok": False, "error": "Server error"}), 500


@app.route("/favicon.ico")
def favicon():
    return send_from_directory(os.path.join(app.static_folder, "img"), "favicon.png")


if __name__ == "__main__":
    try:
        import flask.cli
        flask.cli.show_server_banner = lambda *a, **k: None
    except Exception:
        pass
    cli = sys.modules.get("flask.cli")
    if cli is not None:
        cli.show_server_banner = lambda *a, **k: None
    try:
        app.run(host="0.0.0.0", port=8080, debug=False, threaded=True, use_reloader=False)
    except Exception as e:
        write_error(e)
