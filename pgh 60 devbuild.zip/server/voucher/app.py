import os
import sys
import logging
import traceback
from datetime import datetime
from flask import Flask, jsonify, render_template, request
from werkzeug.exceptions import HTTPException

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ERROR_FILE = os.path.join(ROOT, "voucher_errors.txt")
sys.path.insert(0, ROOT)
import vouchers_lib

logging.getLogger("werkzeug").disabled = True
logging.getLogger("werkzeug").setLevel(logging.CRITICAL)

app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(__file__), "templates"),
    static_folder=os.path.join(os.path.dirname(__file__), "static"),
)
app.logger.disabled = True
app.config["JSON_AS_ASCII"] = False


def write_error(err):
    try:
        with open(ERROR_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {err}\n")
            f.write(traceback.format_exc())
            f.write("\n")
    except Exception:
        pass


@app.route("/")
def maker():
    return render_template(
        "maker.html",
        types=vouchers_lib.REWARD_TYPES,
        brawlers=vouchers_lib.BRAWLERS,
    )


@app.route("/en/")
@app.route("/en")
def claim_en():
    code = (request.args.get("code") or "").strip()
    action = (request.args.get("action") or "").strip()
    return render_template("claim.html", code=code, action=action)


@app.route("/api/create", methods=["POST"])
def api_create():
    data = request.get_json(silent=True) or {}
    raw_items = data.get("items") or []
    items = []
    for it in raw_items:
        try:
            oid = int(it.get("ID") or it.get("id") or 0)
        except (TypeError, ValueError):
            continue
        if oid <= 0:
            continue
        try:
            amount = int(it.get("Multiplier") or it.get("amount") or 1)
        except (TypeError, ValueError):
            amount = 1
        try:
            brawler = int(it.get("BrawlerID") or it.get("brawler") or 0)
        except (TypeError, ValueError):
            brawler = 0
        try:
            skin = int(it.get("SkinID") or it.get("skin") or 0)
        except (TypeError, ValueError):
            skin = 0
        items.append({
            "ID": oid,
            "Multiplier": amount,
            "BrawlerID": brawler,
            "SkinID": skin,
        })
    if not items:
        return jsonify({"ok": False, "error": "Add at least one reward."}), 400
    offer = vouchers_lib.create(items)
    code = offer["Voucher"]
    base = request.host_url.rstrip("/")
    link = f"{base}/en/?action=voucher&code={code}"
    return jsonify({"ok": True, "code": code, "link": link, "voucher": offer})


@app.errorhandler(Exception)
def on_error(err):
    if isinstance(err, HTTPException):
        return err
    write_error(err)
    return jsonify({"ok": False, "error": "Server error"}), 500


if __name__ == "__main__":
    try:
        import flask.cli
        flask.cli.show_server_banner = lambda *a, **k: None
    except Exception:
        pass
    try:
        vouchers_lib.ensure()
        app.run(host="0.0.0.0", port=8083, debug=False, threaded=True, use_reloader=False)
    except Exception as e:
        write_error(e)
