const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const state = {
  offers: [],
  meta: { brawlers: [], skins: [], patterns: [], gallery: [] },
  show: "all",
  sort: "active",
  selected: new Set(),
  bgKind: "pattern",
  bgValue: "pack-purple",
  editing: null,
};

function toast(msg) {
  const el = $("#toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 2200);
}

function media(path) {
  if (!path) return "";
  if (path.startsWith("http") || path.startsWith("/static/")) return path;
  if (path.startsWith("/media/")) return path;
  return "/media/" + path.replace(/^\//, "");
}

async function loadMeta() {
  const res = await fetch("/api/meta");
  const data = await res.json();
  state.meta = data;
  const sel = $("#brawler");
  sel.innerHTML = data.brawlers.map((b) => `<option value="${b.id}">${b.name}</option>`).join("");
  const box = $("#patternBox");
  box.innerHTML = data.patterns.map((p) =>
    `<button type="button" class="swatch${p.id === state.bgValue ? " on" : ""}" data-id="${p.id}" style="background:${p.css}"><span>${p.name}</span></button>`
  ).join("");
  const gal = $("#galleryBox");
  gal.innerHTML = data.gallery.map((g) =>
    `<button type="button" class="swatch" data-id="${g.id}" style="background:url('/media/${g.file}') center/cover"><span>${g.name}</span></button>`
  ).join("");
}

async function loadOffers() {
  const res = await fetch("/api/offers");
  const data = await res.json();
  state.offers = data.offers || [];
  renderTable();
}

function filtered() {
  let rows = state.offers.slice();
  const q = ($("#search").value || "").toLowerCase();
  if (state.show === "active") rows = rows.filter((o) => o.active);
  if (state.show === "inactive") rows = rows.filter((o) => !o.active);
  if (q) rows = rows.filter((o) => `${o.id} ${o.name} ${o.brawler} ${o.skin_id}`.toLowerCase().includes(q));
  if (state.sort === "active") rows.sort((a, b) => Number(b.active) - Number(a.active) || b.id - a.id);
  else rows.sort((a, b) => a.id - b.id);
  return rows;
}

function renderTable() {
  const rows = filtered();
  $("#countLabel").textContent = `${rows.length} item${rows.length === 1 ? "" : "s"}`;
  $("#tbody").innerHTML = rows.map((o) => {
    const gems = o.discount ? `<s class="muted">${o.old_gems}</s> ${o.gems}` : String(o.gems);
    const checked = state.selected.has(o.id) ? "checked" : "";
    return `<tr data-id="${o.id}">
      <td><div class="status ${o.active ? "" : "off"}"></div></td>
      <td><input type="checkbox" ${checked} data-check="${o.id}"/></td>
      <td>${o.id}</td>
      <td>${escapeHtml(o.name)}</td>
      <td>${escapeHtml(o.type)}</td>
      <td>${o.skin_id}</td>
      <td>${escapeHtml(o.brawler || "—")}</td>
      <td>${gems}</td>
      <td>${escapeHtml(o.bg_kind)}</td>
    </tr>`;
  }).join("");
}

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function showList() {
  $("#listWrap").classList.remove("hide");
  $("#formWrap").classList.remove("show");
  state.editing = null;
}

function showForm(offer) {
  $("#listWrap").classList.add("hide");
  $("#formWrap").classList.add("show");
  $("#formTitle").textContent = offer ? "EDIT OFFER" : "ADD OFFER";
  state.editing = offer ? offer.id : null;
  $("#offerId").value = offer ? offer.id : "";
  $("#skinId").value = offer ? offer.skin_id : "";
  $("#brawler").value = offer ? offer.brawler_id : 0;
  $("#name").value = offer ? offer.name : "";
  $("#gems").value = offer ? offer.gems : 80;
  $("#oldGems").value = offer && offer.old_gems ? offer.old_gems : 0;
  $("#active").checked = offer ? offer.active : true;
  $("#photo").value = "";
  $("#gif").value = "";
  $("#photoName").textContent = offer && offer.photo ? offer.photo : "Optional. PNG, JPG, WEBP or GIF.";
  state.bgKind = offer ? offer.bg_kind : "pattern";
  state.bgValue = offer ? offer.bg_value : "pack-purple";
  setBgKind(state.bgKind);
  if (offer && offer.photo) {
    $("#previewArt").src = offer.photo.startsWith("/") ? offer.photo.replace("/static/offers/", "/media/") : media(offer.photo);
    $("#previewArt").style.display = "";
  } else {
    $("#previewArt").removeAttribute("src");
    $("#previewArt").style.display = "none";
  }
  updatePreview();
}

function setBgKind(kind) {
  state.bgKind = kind;
  $$(".bg-opts .pill").forEach((p) => p.classList.toggle("on", p.dataset.bg === kind));
  $("#patternBox").hidden = kind !== "pattern";
  $("#galleryBox").hidden = kind !== "gallery";
  $("#gifBox").hidden = kind !== "gif";
  $$("#patternBox .swatch").forEach((s) => s.classList.toggle("on", s.dataset.id === state.bgValue));
  $$("#galleryBox .swatch").forEach((s) => s.classList.toggle("on", s.dataset.id === state.bgValue));
  updatePreview();
}

function currentBgCss() {
  if (state.bgKind === "pattern") {
    const p = state.meta.patterns.find((x) => x.id === state.bgValue);
    return p ? p.css : "#7a1cc7";
  }
  if (state.bgKind === "gallery") {
    const g = state.meta.gallery.find((x) => x.id === state.bgValue);
    return g ? `url('/media/${g.file}') center / cover` : "#7a1cc7";
  }
  return $("#preview").style.backgroundImage ? $("#preview").style.background : "#7a1cc7";
}

function updatePreview() {
  const name = $("#name").value || "Skin";
  const gems = $("#gems").value || "0";
  const old = Number($("#oldGems").value || 0);
  const bid = Number($("#brawler").value || 0);
  const b = state.meta.brawlers.find((x) => x.id === bid);
  $("#previewName").textContent = name;
  $("#previewBrawler").textContent = b ? b.name : "";
  $("#previewGems").textContent = gems;
  if (old > Number(gems)) {
    $("#previewOld").hidden = false;
    $("#previewOld").textContent = old;
  } else {
    $("#previewOld").hidden = true;
  }
  if (state.bgKind !== "gif" || !($("#gif").files && $("#gif").files[0])) {
    $("#preview").style.background = currentBgCss();
  }
}

function applySkinId() {
  const id = Number($("#skinId").value);
  const skin = (state.meta.skins || []).find((s) => s.id === id);
  if (!skin) return;
  if (!$("#name").value) $("#name").value = skin.name;
  if (skin.brawler_id) $("#brawler").value = skin.brawler_id;
  if (skin.cost && Number($("#gems").value) === 80) $("#gems").value = skin.cost;
  updatePreview();
}

async function saveOffer() {
  const fd = new FormData();
  const oid = $("#offerId").value;
  fd.append("name", $("#name").value);
  fd.append("skin_id", $("#skinId").value);
  fd.append("brawler_id", $("#brawler").value);
  const b = state.meta.brawlers.find((x) => x.id === Number($("#brawler").value));
  fd.append("brawler", b ? b.name : "");
  fd.append("gems", $("#gems").value);
  fd.append("old_gems", $("#oldGems").value || "0");
  fd.append("active", $("#active").checked ? "true" : "false");
  fd.append("bg_kind", state.bgKind);
  fd.append("bg_value", state.bgValue || "");
  if ($("#photo").files[0]) fd.append("photo", $("#photo").files[0]);
  if ($("#gif").files[0]) fd.append("gif", $("#gif").files[0]);
  const url = oid ? `/api/offers/${oid}` : "/api/offers";
  const res = await fetch(url, { method: "POST", body: fd });
  const data = await res.json();
  if (!res.ok || !data.ok) {
    toast(data.error || "Could not save.");
    return;
  }
  toast("Offer saved");
  await loadOffers();
  showList();
}

function selectedIds() {
  return [...state.selected];
}

$("#addBtn").addEventListener("click", (e) => {
  e.stopPropagation();
  $("#addMenu").classList.toggle("show");
  $("#actionsMenu").classList.remove("show");
});
$("#addMenu").addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;
  $("#addMenu").classList.remove("show");
  showForm(null);
});
$("#addSeqBtn").addEventListener("click", () => showForm(null));
$("#cloneBtn").addEventListener("click", async () => {
  const ids = selectedIds();
  if (!ids.length) { toast("Select an offer first"); return; }
  await fetch("/api/offers/clone", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ids }),
  });
  state.selected.clear();
  await loadOffers();
  toast("Cloned");
});
$("#actionsBtn").addEventListener("click", (e) => {
  e.stopPropagation();
  $("#actionsMenu").classList.toggle("show");
  $("#addMenu").classList.remove("show");
});
$("#actionsMenu").addEventListener("click", async (e) => {
  const act = e.target.dataset.act;
  const ids = selectedIds();
  if (!ids.length) { toast("Select an offer first"); return; }
  if (act === "delete") {
    await fetch("/api/offers/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids }),
    });
  } else {
    for (const id of ids) {
      const fd = new FormData();
      const o = state.offers.find((x) => x.id === id);
      if (!o) continue;
      fd.append("name", o.name);
      fd.append("skin_id", o.skin_id);
      fd.append("brawler_id", o.brawler_id);
      fd.append("brawler", o.brawler);
      fd.append("gems", o.gems);
      fd.append("old_gems", o.old_gems || 0);
      fd.append("bg_kind", o.bg_kind);
      fd.append("bg_value", o.bg_value || "");
      fd.append("active", act === "on" ? "true" : "false");
      await fetch(`/api/offers/${id}`, { method: "POST", body: fd });
    }
  }
  state.selected.clear();
  $("#actionsMenu").classList.remove("show");
  await loadOffers();
});
document.addEventListener("click", () => {
  $("#addMenu").classList.remove("show");
  $("#actionsMenu").classList.remove("show");
});

$$("[data-show]").forEach((b) => b.addEventListener("click", () => {
  state.show = b.dataset.show;
  $$("[data-show]").forEach((x) => x.classList.toggle("on", x === b));
  renderTable();
}));
$$("[data-sort]").forEach((b) => b.addEventListener("click", () => {
  state.sort = b.dataset.sort;
  $$("[data-sort]").forEach((x) => x.classList.toggle("on", x === b));
  renderTable();
}));
$("#search").addEventListener("input", renderTable);

$("#tbody").addEventListener("click", (e) => {
  const tr = e.target.closest("tr");
  if (!tr) return;
  const id = Number(tr.dataset.id);
  if (e.target.matches("input[type=checkbox]")) {
    if (e.target.checked) state.selected.add(id);
    else state.selected.delete(id);
    return;
  }
  const offer = state.offers.find((o) => o.id === id);
  if (offer) showForm(offer);
});

$("#backBtn").addEventListener("click", showList);
$("#cancelBtn").addEventListener("click", showList);
$("#saveBtn").addEventListener("click", saveOffer);
$("#saveBtn2").addEventListener("click", saveOffer);
$("#skinId").addEventListener("change", applySkinId);
$("#name").addEventListener("input", updatePreview);
$("#gems").addEventListener("input", updatePreview);
$("#oldGems").addEventListener("input", updatePreview);
$("#brawler").addEventListener("change", updatePreview);
$$(".bg-opts .pill").forEach((p) => p.addEventListener("click", () => {
  if (p.dataset.bg === "pattern") state.bgValue = "pack-purple";
  if (p.dataset.bg === "gallery") state.bgValue = "g1";
  setBgKind(p.dataset.bg);
}));
$("#patternBox").addEventListener("click", (e) => {
  const s = e.target.closest(".swatch");
  if (!s) return;
  state.bgValue = s.dataset.id;
  setBgKind("pattern");
});
$("#galleryBox").addEventListener("click", (e) => {
  const s = e.target.closest(".swatch");
  if (!s) return;
  state.bgValue = s.dataset.id;
  setBgKind("gallery");
});
$("#photo").addEventListener("change", () => {
  const f = $("#photo").files[0];
  if (!f) return;
  $("#photoName").textContent = f.name;
  $("#previewArt").src = URL.createObjectURL(f);
  $("#previewArt").style.display = "";
});
$("#gif").addEventListener("change", () => {
  const f = $("#gif").files[0];
  if (!f) return;
  $("#preview").style.background = `url('${URL.createObjectURL(f)}') center / cover`;
});

loadMeta().then(loadOffers).catch(() => toast("Could not load panel"));
