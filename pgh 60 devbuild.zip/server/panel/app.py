import os
import sys
import json
import uuid
import logging
import traceback
from datetime import datetime
from flask import Flask, jsonify, render_template, request, send_from_directory
from werkzeug.exceptions import HTTPException
from werkzeug.utils import secure_filename

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ERROR_FILE = os.path.join(ROOT, "panel_errors.txt")
sys.path.insert(0, ROOT)
import offers_store

logging.getLogger("werkzeug").disabled = True
logging.getLogger("werkzeug").setLevel(logging.CRITICAL)

app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(__file__), "templates"),
    static_folder=os.path.join(os.path.dirname(__file__), "static"),
)
app.logger.disabled = True
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
app.config["JSON_AS_ASCII"] = False

ALLOWED = {".png", ".jpg", ".jpeg", ".webp", ".gif"}


def write_error(err):
    try:
        with open(ERROR_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {err}\n")
            f.write(traceback.format_exc())
            f.write("\n")
    except Exception:
        pass


def form_payload(req, existing=None):
    existing = existing or {}
    data = req.form if req.form else (req.get_json(silent=True) or {})
    name = (data.get("name") or "").strip()
    try:
        skin_id = int(data.get("skin_id") or 0)
    except (TypeError, ValueError):
        skin_id = 0
    try:
        brawler_id = int(data.get("brawler_id") or 0)
    except (TypeError, ValueError):
        brawler_id = 0
    brawler = (data.get("brawler") or "").strip()
    if not brawler:
        for b in offers_store.BRAWLERS:
            if b["id"] == brawler_id:
                brawler = b["name"]
                break
    if not name:
        skin = offers_store.SKIN_BY_ID.get(skin_id)
        name = skin["name"] if skin else "Skin"
    try:
        gems = int(data.get("gems") or 0)
    except (TypeError, ValueError):
        gems = 0
    try:
        old_gems = int(data.get("old_gems") or 0)
    except (TypeError, ValueError):
        old_gems = 0
    active_raw = data.get("active")
    if isinstance(active_raw, str):
        active = active_raw.lower() in ("1", "true", "on", "yes")
    elif active_raw is None:
        active = True if existing.get("active", True) else False
    else:
        active = bool(active_raw)
    photo = existing.get("photo") or ""
    bg_kind = data.get("bg_kind") or existing.get("bg_kind") or "pattern"
    bg_value = data.get("bg_value") if data.get("bg_value") is not None else existing.get("bg_value")
    return {
        "name": name,
        "skin_id": skin_id,
        "brawler_id": brawler_id,
        "brawler": brawler,
        "gems": gems,
        "old_gems": old_gems,
        "photo": photo,
        "bg_kind": bg_kind,
        "bg_value": bg_value,
        "active": active,
    }


def save_upload(file_storage, folder=""):
    if not file_storage or not file_storage.filename:
        return ""
    ext = os.path.splitext(file_storage.filename)[1].lower()
    if ext not in ALLOWED:
        return ""
    offers_store.ensure_files()
    name = uuid.uuid4().hex + ext
    dest_dir = os.path.join(offers_store.UPLOAD_DIR, folder) if folder else offers_store.UPLOAD_DIR
    os.makedirs(dest_dir, exist_ok=True)
    path = os.path.join(dest_dir, secure_filename(name))
    file_storage.save(path)
    return f"{folder}/{name}" if folder else name


@app.route("/")
def home():
    return render_template("offers.html")


@app.route("/api/meta")
def api_meta():
    return jsonify({
        "ok": True,
        "brawlers": offers_store.BRAWLERS,
        "skins": offers_store.SKINS,
        "patterns": offers_store.PATTERNS,
        "gallery": offers_store.GALLERY,
    })


@app.route("/api/offers")
def api_offers():
    return jsonify({"ok": True, "offers": offers_store.list_offers(active_only=False)})


@app.route("/api/offers", methods=["POST"])
def api_create():
    payload = form_payload(request)
    photo = save_upload(request.files.get("photo"))
    gif = save_upload(request.files.get("gif"))
    if photo:
        payload["photo"] = photo
    if gif:
        payload["bg_kind"] = "gif"
        payload["bg_value"] = gif
    offer = offers_store.upsert_offer(payload)
    return jsonify({"ok": True, "offer": offers_store.public_offer(offer)})


@app.route("/api/offers/<int:oid>", methods=["POST", "PATCH", "PUT"])
def api_update(oid):
    existing = offers_store.get_offer(oid)
    if not existing:
        return jsonify({"ok": False, "error": "Offer not found."}), 404
    payload = form_payload(request, existing)
    photo = save_upload(request.files.get("photo"))
    gif = save_upload(request.files.get("gif"))
    if photo:
        payload["photo"] = photo
    else:
        payload["photo"] = existing.get("photo") or ""
    if gif:
        payload["bg_kind"] = "gif"
        payload["bg_value"] = gif
    offer = offers_store.upsert_offer(payload, existing_id=oid)
    return jsonify({"ok": True, "offer": offers_store.public_offer(offer)})


@app.route("/api/offers/delete", methods=["POST"])
def api_delete():
    data = request.get_json(silent=True) or {}
    ids = data.get("ids") or []
    offers_store.delete_offers(ids)
    return jsonify({"ok": True})


@app.route("/api/offers/clone", methods=["POST"])
def api_clone():
    data = request.get_json(silent=True) or {}
    ids = data.get("ids") or []
    clones = offers_store.clone_offers(ids)
    return jsonify({"ok": True, "offers": [offers_store.public_offer(c) for c in clones]})


@app.route("/media/<path:name>")
def media(name):
    return send_from_directory(offers_store.UPLOAD_DIR, name)


@app.errorhandler(Exception)
def on_error(err):
    if isinstance(err, HTTPException):
        return err
    write_error(err)
    return jsonify({"ok": False, "error": "Server error"}), 500


if __name__ == "__main__":
    try:
        import flask.cli
        flask.cli.show_server_banner = lambda *a, **k: None
    except Exception:
        pass
    try:
        offers_store.ensure_files()
        app.run(host="0.0.0.0", port=8082, debug=False, threaded=True, use_reloader=False)
    except Exception as e:
        write_error(e)
