import json
import time
import random
from urllib.parse import urlparse, parse_qs, unquote

import os
import sys

from Utils.Reader import BSMessageReader
from database.DataBase import DataBase
from Logic.LogicBuy import LogicBuy
from Logic.Pin import Pin
from Logic.Commands.Server.LogicTropRoad import LogicTropRoad
from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd as Supply

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
import vouchers_lib


class AnalyticsEventMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.Type = ""
        self.Event = ""

    def decode(self):
        try:
            self.Type = self.read_string()
            self.Event = self.read_string()
        except Exception:
            self.Type = ""
            self.Event = ""

    def process(self, db=None):
        try:
            self._handle()
        except Exception:
            return

    def _handle(self):
        raw = self.Event or ""
        data = None
        if raw:
            try:
                data = json.loads(raw)
            except Exception:
                data = None
        code = self._extract_code(data, raw)
        if not code:
            return
        voucher = vouchers_lib.find(code)
        if not voucher:
            return
        pid = int(self.player.low_id)
        if vouchers_lib.used_by(voucher, pid):
            self._notif("apparently, their eyes are bigger than their stomach")
            return
        for item_data in voucher.get("Items") or []:
            try:
                offer_id = int(item_data.get("ID") or 0)
                offer_amount = int(item_data.get("Multiplier") or 0)
                offer_char = int(item_data.get("BrawlerID") or 0)
                offer_itemID = int(item_data.get("SkinID") or 0)
            except (TypeError, ValueError):
                continue
            self._give(offer_id, offer_amount, offer_char, offer_itemID)
        vouchers_lib.mark_used(code, pid)
        self._notif("Voucher redeemed")

    def _extract_code(self, data, raw):
        if isinstance(data, dict):
            if data.get("code"):
                return str(data.get("code")).strip()
            link = unquote(str(data.get("link") or ""))
            code = self._from_text(link)
            if code:
                return code
        return self._from_text(unquote(str(raw or "")))

    def _from_text(self, text):
        text = (text or "").strip()
        if not text:
            return ""
        if "code=" in text:
            try:
                if "://" not in text and text.startswith("?"):
                    text = "http://x" + text
                elif "://" not in text and "code=" in text:
                    text = "http://x/?" + text.split("?", 1)[-1] if "?" in text else "http://x/?" + text
                q = parse_qs(urlparse(text).query)
                if q.get("code"):
                    return q["code"][0].strip()
            except Exception:
                pass
        if "voucher/" in text:
            part = text.split("voucher/", 1)[1]
            return part.strip("/").split("?")[0].split("&")[0].strip()
        if text.isalnum() and len(text) <= 32:
            return text
        return ""

    def _notif(self, msg):
        if not isinstance(self.player.notifs, list):
            self.player.notifs = []
        self.player.notifs.append({
            "ID": 81,
            "index": random.randint(1, 999999999),
            "seen": False,
            "ago": int(time.time()),
            "msg": msg,
            "msg_TYPE": 1,
        })
        DataBase.replaceValue(self, "notifs", json.dumps(self.player.notifs))

    def _give(self, offer_id, amount, brawler_id, skin_id):
        if offer_id == 1:
            LogicTropRoad(self.client, self.player, 100, amount).send()
        elif offer_id == 16:
            LogicBuy(self.client, self.player, 2, 0, 0, amount, 0, 0, 0, 0, 0, 0, 0, 0).send()
        elif offer_id == 19:
            Pin(self.client, self.player, skin_id).send()
        elif offer_id == 9:
            self.player.tokensdoubler = int(getattr(self.player, "tokensdoubler", 0) or 0) + amount
        elif offer_id == 3:
            LogicBuy(self.client, self.player, 6, 0, 0, 1, 0, 0, brawler_id, 0, 0, 0, 0, 0).send()
        elif offer_id == 8:
            LogicTropRoad(self.client, self.player, 100, amount, 6, brawler_id).send()
        elif offer_id in (4, 24):
            bid = int(brawler_id or 0)
            if bid <= 0:
                bid = self._brawler_for_skin(skin_id)
            self._unlock_brawler(bid)
            LogicBuy(self.client, self.player, 7, 0, 0, 0, 0, 0, 0, 0, 0, skin_id, 0, 0).send()
        elif offer_id in (0, 6):
            Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 10}).send()
        elif offer_id == 14:
            Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 12}).send()
        elif offer_id == 10:
            Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 11}).send()
        elif offer_id == 25:
            self._give_pass()

    def _brawler_for_skin(self, skin_id):
        try:
            import offers_store
            skin = offers_store.SKIN_BY_ID.get(int(skin_id))
            if skin:
                return int(skin.get("brawler_id") or 0)
        except Exception:
            pass
        return 0

    def _unlock_brawler(self, brawler_id):
        try:
            bid = int(brawler_id or 0)
        except (TypeError, ValueError):
            return
        if bid < 0:
            return
        if not isinstance(self.player.UnlockedBrawlers, dict):
            self.player.UnlockedBrawlers = {}
        try:
            owned = int(self.player.UnlockedBrawlers.get(str(bid), 0) or 0)
        except Exception:
            owned = 0
        if owned == 1:
            return
        self.player.UnlockedBrawlers[str(bid)] = 1
        DataBase.replaceValue(self, "UnlockedBrawlers", self.player.UnlockedBrawlers)

    def _give_pass(self):
        with open("config.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        buy = config.get("buybp") or []
        pid = int(self.player.low_id)
        if pid not in buy:
            buy.append(pid)
            config["buybp"] = buy
            with open("config.json", "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4)
