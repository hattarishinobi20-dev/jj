import os
import json

ROOT = os.path.dirname(os.path.abspath(__file__))
VOUCHERS_PATH = os.path.join(ROOT, "JSON", "vouchers.json")

BRAWLERS = [
    {"id": 0, "name": "SHELLY"}, {"id": 1, "name": "COLT"}, {"id": 2, "name": "BULL"},
    {"id": 3, "name": "BROCK"}, {"id": 4, "name": "RICO"}, {"id": 5, "name": "SPIKE"},
    {"id": 6, "name": "BARLEY"}, {"id": 7, "name": "JESSIE"}, {"id": 8, "name": "NITA"},
    {"id": 9, "name": "DYNAMIKE"}, {"id": 10, "name": "EL PRIMO"}, {"id": 11, "name": "MORTIS"},
    {"id": 12, "name": "CROW"}, {"id": 13, "name": "POCO"}, {"id": 14, "name": "BO"},
    {"id": 15, "name": "PIPER"}, {"id": 16, "name": "PAM"}, {"id": 17, "name": "TARA"},
    {"id": 18, "name": "DARRYL"}, {"id": 19, "name": "PENNY"}, {"id": 20, "name": "FRANK"},
    {"id": 21, "name": "GENE"}, {"id": 22, "name": "TICK"}, {"id": 23, "name": "LEON"},
    {"id": 24, "name": "ROSA"}, {"id": 25, "name": "CARL"}, {"id": 26, "name": "BIBI"},
    {"id": 27, "name": "8-BIT"}, {"id": 28, "name": "SANDY"}, {"id": 29, "name": "BEA"},
    {"id": 30, "name": "EMZ"}, {"id": 31, "name": "MR. P"}, {"id": 32, "name": "MAX"},
    {"id": 34, "name": "JACKY"}, {"id": 35, "name": "GALE"}, {"id": 36, "name": "NANI"},
    {"id": 37, "name": "SPROUT"}, {"id": 38, "name": "SURGE"}, {"id": 39, "name": "COLETTE"},
]

REWARD_TYPES = [
    {"id": 1, "name": "Gold", "need": "amount"},
    {"id": 16, "name": "Gems", "need": "amount"},
    {"id": 3, "name": "Brawler", "need": "brawler"},
    {"id": 4, "name": "Skin", "need": "skin"},
    {"id": 19, "name": "Pin", "need": "skin"},
    {"id": 8, "name": "Power points", "need": "brawler_amount"},
    {"id": 9, "name": "Token doubler", "need": "amount"},
    {"id": 6, "name": "Brawl box", "need": "none"},
    {"id": 14, "name": "Big box", "need": "none"},
    {"id": 10, "name": "Mega box", "need": "none"},
    {"id": 25, "name": "Brawl Pass", "need": "none"},
]


def ensure():
    os.makedirs(os.path.dirname(VOUCHERS_PATH), exist_ok=True)
    if not os.path.exists(VOUCHERS_PATH):
        with open(VOUCHERS_PATH, "w", encoding="utf-8") as f:
            json.dump([], f)


def load():
    ensure()
    try:
        with open(VOUCHERS_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save(data):
    ensure()
    tmp = VOUCHERS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)
    os.replace(tmp, VOUCHERS_PATH)


def next_code(data=None):
    data = data if data is not None else load()
    nums = []
    for v in data:
        try:
            nums.append(int(str(v.get("Voucher") or "0")))
        except (TypeError, ValueError):
            pass
    return str((max(nums) + 1) if nums else 1)


def create(items):
    data = load()
    code = next_code(data)
    offer = {
        "Voucher": code,
        "WhoUsed": [],
        "Items": items,
    }
    data.append(offer)
    save(data)
    return offer


def find(code):
    code = str(code or "").strip()
    for v in load():
        if str(v.get("Voucher") or "") == code:
            return v
    return None


def mark_used(code, low_id):
    data = load()
    code = str(code)
    pid = int(low_id)
    for v in data:
        if str(v.get("Voucher") or "") == code:
            used = v.get("WhoUsed") or []
            if pid not in used:
                used.append(pid)
                v["WhoUsed"] = used
                save(data)
            return v
    return None


def used_by(voucher, low_id):
    used = voucher.get("WhoUsed") or []
    pid = int(low_id)
    return pid in used or str(pid) in used
