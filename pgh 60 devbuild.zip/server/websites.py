import os
import sys
import time
import traceback
from threading import Thread

ROOT = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(ROOT, "websites_errors.txt")
_STARTED = False


def _log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("[%Y-%m-%d %H:%M:%S] ") + str(msg) + "\n")
    except Exception:
        pass


def _ensure_flask():
    try:
        import flask  # noqa: F401
        return True
    except Exception:
        pass
    try:
        import subprocess
        subprocess.call(
            [sys.executable, "-m", "pip", "install", "flask", "-q"],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        import flask  # noqa: F401
        return True
    except Exception as e:
        _log("flask: %s" % e)
        return False


def _port_busy(port):
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", int(port)))
        return False
    except OSError:
        return True
    finally:
        try:
            s.close()
        except Exception:
            pass


def _boot(name, rel, port):
    import importlib.util
    import logging

    path = os.path.join(ROOT, rel)

    def run():
        try:
            if ROOT not in sys.path:
                sys.path.insert(0, ROOT)
            try:
                import flask.cli
                flask.cli.show_server_banner = lambda *a, **k: None
            except Exception:
                pass
            logging.getLogger("werkzeug").disabled = True
            logging.getLogger("werkzeug").setLevel(logging.CRITICAL)
            spec = importlib.util.spec_from_file_location(name, path)
            mod = importlib.util.module_from_spec(spec)
            sys.modules[name] = mod
            spec.loader.exec_module(mod)
            _log("%s 0.0.0.0:%s" % (name, port))
            mod.app.run(
                host="0.0.0.0",
                port=int(port),
                debug=False,
                threaded=True,
                use_reloader=False,
            )
        except Exception:
            _log(traceback.format_exc())

    Thread(target=run, daemon=True).start()


def start_websites():
    global _STARTED
    if _STARTED:
        return
    if _port_busy(8080):
        _STARTED = True
        return
    _STARTED = True
    os.chdir(ROOT)
    if not _ensure_flask():
        return
    _boot("pg_store", os.path.join("site", "app.py"), 8080)
    _boot("pg_lookup", os.path.join("lookup", "app.py"), 8081)
    _boot("pg_panel", os.path.join("panel", "app.py"), 8082)
    _boot("pg_voucher", os.path.join("voucher", "app.py"), 8083)
    _boot("pg_event", os.path.join("event", "app.py"), 8084)


if __name__ == "__main__":
    start_websites()
    while True:
        time.sleep(60)
