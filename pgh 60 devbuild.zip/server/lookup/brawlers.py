NAMES = {
    0: "SHELLY", 1: "COLT", 2: "BULL", 3: "BROCK", 4: "RICO",
    5: "SPIKE", 6: "BARLEY", 7: "JESSIE", 8: "NITA", 9: "DYNAMIKE",
    10: "EL PRIMO", 11: "MORTIS", 12: "CROW", 13: "POCO", 14: "BO",
    15: "PIPER", 16: "PAM", 17: "TARA", 18: "DARRYL", 19: "PENNY",
    20: "FRANK", 21: "GENE", 22: "TICK", 23: "LEON", 24: "ROSA",
    25: "CARL", 26: "BIBI", 27: "8-BIT", 28: "SANDY", 29: "BEA",
    30: "EMZ", 31: "MR. P", 32: "MAX", 34: "JACKY", 35: "GALE",
    36: "NANI", 37: "SPROUT", 38: "SURGE", 39: "COLETTE",
}

RARITY = {
    0: "common", 7: "common", 9: "common", 14: "common", 22: "common", 27: "common", 30: "common",
    1: "rare", 2: "rare", 3: "rare", 6: "rare", 8: "rare", 10: "rare", 13: "rare", 24: "rare",
    4: "superrare", 18: "superrare", 19: "superrare", 25: "superrare", 34: "superrare",
    15: "epic", 16: "epic", 20: "epic", 26: "epic", 29: "epic", 36: "epic",
    11: "mythic", 17: "mythic", 21: "mythic", 31: "mythic", 32: "mythic", 37: "mythic",
    5: "legendary", 12: "legendary", 23: "legendary", 28: "legendary",
    35: "chromatic", 38: "chromatic", 39: "chromatic",
}


def rank_from_trophies(t):
    t = int(t or 0)
    thresholds = [0, 10, 20, 30, 40, 60, 80, 100, 120, 140, 160, 180, 220, 260, 300, 340, 380, 420, 460, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1050, 1100, 1150, 1200, 1250]
    r = 1
    for i, th in enumerate(thresholds):
        if t >= th:
            r = i + 1
    return r
