import os
import sys
import json
import sqlite3
import logging
import traceback
from datetime import datetime
from flask import Flask, redirect, render_template, request, url_for

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(ROOT, "database", "Player", "plr.db")
CLUB_DB = os.path.join(ROOT, "database", "Club", "clubs.db")
ERROR_FILE = os.path.join(ROOT, "lookup_errors.txt")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from brawlers import NAMES, RARITY, rank_from_trophies

logging.getLogger("werkzeug").disabled = True
logging.getLogger("werkzeug").setLevel(logging.CRITICAL)

app = Flask(
    __name__,
    template_folder=os.path.join(os.path.dirname(__file__), "templates"),
    static_folder=os.path.join(os.path.dirname(__file__), "static"),
)
app.logger.disabled = True


def write_error(err):
    try:
        with open(ERROR_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {err}\n")
            f.write(traceback.format_exc())
            f.write("\n")
    except Exception:
        pass


def db(path=DB_PATH):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def club_info(club_id):
    if not club_id or int(club_id) == 0 or not os.path.exists(CLUB_DB):
        return None
    conn = db(CLUB_DB)
    try:
        row = conn.execute("SELECT clubID, name, badgeID FROM clubs WHERE clubID = ?", (int(club_id),)).fetchone()
        if not row:
            return None
        return {"id": int(row["clubID"]), "name": row["name"] or "Club", "badge": int(row["badgeID"] or 0)}
    except Exception:
        return None
    finally:
        conn.close()


def load_player(low_id):
    try:
        low_id = int(str(low_id).strip().lstrip("#"))
    except (TypeError, ValueError):
        return None
    if low_id < 2 or not os.path.exists(DB_PATH):
        return None
    conn = db()
    try:
        row = conn.execute("SELECT * FROM plrs WHERE lowID = ?", (low_id,)).fetchone()
        if not row:
            return None
        cols = row.keys()
        data = {k: row[k] for k in cols}
        try:
            bd = json.loads(data.get("brawlerData") or "{}")
        except Exception:
            bd = {}
        unlocked = bd.get("UnlockedBrawlers") or {}
        trophies = bd.get("brawlersTrophies") or {}
        power = bd.get("brawlerPowerLevel") or {}
        points_map = bd.get("brawlerPoints") or {}
        highest = bd.get("highest_trophies")
        if isinstance(highest, dict):
            best_map = highest
        else:
            best_map = trophies
        gold_need = {1: 20, 2: 35, 3: 75, 4: 140, 5: 290, 6: 480, 7: 800, 8: 1250, 9: 1875}
        point_need = {1: 20, 2: 35, 3: 75, 4: 140, 5: 290, 6: 480, 7: 800, 8: 1250, 9: 1875}
        brawlers = []
        for bid in sorted(NAMES.keys()):
            try:
                on = int(unlocked.get(str(bid), unlocked.get(bid, 0)) or 0) == 1
            except Exception:
                on = False
            tr = int(trophies.get(str(bid), trophies.get(bid, 0)) or 0)
            pw_raw = int(power.get(str(bid), power.get(bid, 0)) or 0)
            pw = max(1, min(11, pw_raw + 1 if pw_raw < 11 else 11))
            pts = int(points_map.get(str(bid), points_map.get(bid, 0)) or 0)
            best = int(best_map.get(str(bid), best_map.get(bid, tr)) or tr) if isinstance(best_map, dict) else tr
            mx = pw >= 10
            rk = max(1, min(35, rank_from_trophies(tr))) if on else 0
            if rk >= 30:
                rk_cls = "gold"
            elif rk >= 21:
                rk_cls = "purple"
            elif rk >= 11:
                rk_cls = "blue"
            else:
                rk_cls = "yellow"
            brawlers.append({
                "id": bid,
                "name": NAMES.get(bid, f"BRAWLER {bid}"),
                "trophies": tr,
                "best": best,
                "power": pw,
                "max": mx,
                "points": pts,
                "need_points": 0 if mx else point_need.get(pw, 890),
                "need_gold": 0 if mx else gold_need.get(pw, 1875),
                "new": on and pw <= 1,
                "rank": rk,
                "rk": rk_cls,
                "locked": not on,
                "rarity": RARITY.get(bid, "common"),
                "img": f"https://cdn.brawlify.com/brawlers/pins/{16000000 + bid}.png",
                "img2": f"https://cdn.brawlify.com/brawlers/portraits/{16000000 + bid}.png",
            })
        unlocked_list = [b for b in brawlers if not b["locked"]]
        unlocked_list.sort(key=lambda x: (-x["rank"], -x["trophies"], x["name"]))
        locked_list = [b for b in brawlers if b["locked"]]
        brawlers = unlocked_list + locked_list
        for i, b in enumerate(unlocked_list[:3]):
            b["top"] = i + 1
        icon = int(data.get("profile_icon") or 0)
        exp = int(data.get("playerExp") or 0)
        return {
            "low_id": int(data["lowID"]),
            "name": data.get("name") or "Player",
            "trophies": int(data.get("trophies") or 0),
            "gems": int(data.get("gems") or 0),
            "gold": int(data.get("gold") or 0),
            "tickets": int(data.get("tickets") or 0),
            "starpoints": int(data.get("starpoints") or 0),
            "exp": exp,
            "level": max(1, exp // 20 + 1),
            "trio": int(data.get("trioWINS") or 0),
            "solo": int(data.get("sdWINS") or 0),
            "duo": 0,
            "vip": int(data.get("vip") or 0),
            "winstreak": int(data.get("winstreak") or 0),
            "highestwinstreak": int(data.get("highestwinstreak") or 0),
            "icon": icon,
            "icon_url": f"https://cdn.brawlify.com/profile-icons/regular/{28000000 + icon}.png",
            "club": club_info(data.get("clubID")),
            "brawlers": brawlers,
            "brawler_count": len(unlocked_list),
            "top": unlocked_list[0] if unlocked_list else None,
        }
    finally:
        conn.close()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/stats", methods=["GET", "POST"])
def stats():
    raw = request.values.get("low_id") or request.values.get("player_tag") or ""
    player = load_player(raw)
    if not player:
        return render_template("stats.html", player=None, query=raw)
    return render_template("stats.html", player=player, query=raw)


@app.errorhandler(Exception)
def on_error(err):
    from werkzeug.exceptions import HTTPException
    if isinstance(err, HTTPException):
        return err
    write_error(err)
    return render_template("stats.html", player=None, query=""), 500


if __name__ == "__main__":
    try:
        import flask.cli
        flask.cli.show_server_banner = lambda *a, **k: None
    except Exception:
        pass
    try:
        app.run(host="0.0.0.0", port=8081, debug=False, threaded=True, use_reloader=False)
    except Exception as e:
        write_error(e)
