import json
import os
import random
import re
import time

class Shop:
    """
    << Список ID предложений в магазине >>

    0 = Бесплатный ящик Brawl Box
    1 = Золото
    2 = Случайный боец
    3 = Боец
    4 = Скин
    5 = Звёздная сила / Гаджет
    6 = Ящик Brawl Box
    7 = Билеты (больше не работают)
    8 = Очки силы (для конкретного бойца)
    9 = Удвоитель жетонов
    10 = Мегаящик
    11 = Ключи (???)
    12 = Очки силы
    13 = Слот события (???)
    14 = Большой ящик
    15 = Рекламный ящик (больше не работает)
    16 = Гемы
    19 = Пин для бойца
    20 = Коллекция пинов
    21 = Набор пинов
    22 = Набор пинов для бойца
    23 = Обычный пин (???)
    24 = Предложение скина в магазине (может не работать)
    94 = Скин (???)

    << Список BGR предложений в магазине >>

    Предложение жетонов = offer_generic
    Специальное предложение = offer_special
    Предложение за звёздные очки = offer_legendary
    Предложение монет = offer_coins (в версии 29 как offer_moon_festival)
    Предложение гемов = offer_gems
    Предложение ящиков = offer_boxes
    Предложение бойца = offer_finals
    Предложение Лунного Нового года = offer_lny
    Архивное предложение = offer_archive
    Хроматическое предложение = offer_chromatic
    Предложение Лунного фестиваля = offer_moon_festival
    Рождественское предложение = offer_xmas

    ET означает дополнительный текст.
    """

    def loadOffers(self):
        self.offers = []
        self.offer_sources = []
        with open("JSON/offers.json", "r", encoding="utf-8") as f:
            data = json.load(f)
            for key, offer in data.items():
                self.offers.append(offer)
                self.offer_sources.append(("global", key))
        for i, offer in enumerate(Shop.LoadDailyOffers(self)):
            self.offers.append(offer)
            self.offer_sources.append(("daily", i))
        for offer in Shop.LoadCommunityOffers(self):
            self.offers.append(offer)
            self.offer_sources.append(("community", int(offer.get("CommunityRewardId") or 0)))

    def LoadOffers(self):
        Shop.loadOffers(self)

    def SkinCatalog(self):
        cached = getattr(Shop, "_skin_catalog", None)
        if cached is not None:
            return cached
        catalog = []
        bid = None
        try:
            with open("Logic/skins.txt", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
        except Exception:
            Shop._skin_catalog = []
            return []
        for line in lines:
            m = re.search(r"бойца:\s*(\d+)", line)
            if m:
                bid = int(m.group(1))
                continue
            if "Не продаётся" in line and "кристалл" not in line:
                continue
            m = re.search(r"(\d+)\s*-.*?(\d+)\s*кристалл", line)
            if m and bid is not None:
                catalog.append({
                    "skinId": int(m.group(1)),
                    "brawlerId": int(bid),
                    "cost": int(m.group(2)),
                })
        Shop._skin_catalog = catalog
        return catalog

    def LoadDailyOffers(self):
        player = getattr(self, "player", None)
        if player is None:
            return []
        catalog = Shop.SkinCatalog(self)
        if not catalog:
            return []
        low = str(int(player.low_id))
        day = time.strftime("%Y-%m-%d")
        path = os.path.join("JSON", "daily_offers", low + ".json")
        data = Shop.LoadJson(self, path, {})
        if isinstance(data, dict) and data.get("key") == day and data.get("version") == 4 and isinstance(data.get("offers"), list) and data["offers"]:
            out = []
            for offer in data["offers"]:
                if not isinstance(offer, dict):
                    continue
                if int((offer.get("ID") or [0])[0] or 0) == 4:
                    out.append(offer)
            if out:
                return out
        owned_skins = set()
        unlocked_skins = getattr(player, "UnlockedSkins", {}) or {}
        if isinstance(unlocked_skins, dict):
            for sid, st in unlocked_skins.items():
                try:
                    if int(st) == 1:
                        owned_skins.add(int(sid))
                except Exception:
                    continue
        owned_br = set()
        ub = getattr(player, "UnlockedBrawlers", {}) or {}
        if isinstance(ub, dict):
            for bid, st in ub.items():
                try:
                    if int(st) == 1:
                        owned_br.add(int(bid))
                except Exception:
                    continue
        pool = [s for s in catalog if int(s["brawlerId"]) in owned_br and int(s["skinId"]) not in owned_skins]
        rng = random.Random("%s-%s" % (low, day))
        n = min(6, len(pool))
        chosen = rng.sample(pool, n) if n else []
        lt = time.localtime()
        timer = max(60, 86400 - (lt.tm_hour * 3600 + lt.tm_min * 60 + lt.tm_sec))
        offers = []
        for s in chosen:
            offers.append({
                "ID": [4, 0, 0],
                "OfferTitle": "DAILY SKIN",
                "SkinID": [int(s["skinId"]), 0, 0],
                "Cost": int(s["cost"]),
                "OldCost": 0,
                "Multiplier": [1, 0, 0],
                "BrawlerID": [int(s["brawlerId"]), 0, 0],
                "OfferView": 0,
                "ETType": 0,
                "ETMultiplier": 0,
                "Timer": timer,
                "OfferBGR": "offer_generic",
                "ShopType": 0,
                "ShopDisplay": 0,
                "WhoBuyed": [],
                "DailyGenerated": True,
            })
        Shop.SaveJson(self, path, {"key": day, "version": 4, "offers": offers})
        return offers

    def OfferItems(self, offer):
        ids = list(offer.get("ID") or [])
        mults = list(offer.get("Multiplier") or [])
        brawlers = list(offer.get("BrawlerID") or [])
        skins = list(offer.get("SkinID") or [])
        n = max(len(ids), len(mults), len(brawlers), len(skins))
        items = []
        for i in range(n):
            try:
                iid = int(ids[i] if i < len(ids) else 0 or 0)
            except Exception:
                iid = 0
            if iid == 0:
                continue
            try:
                mult = int(mults[i] if i < len(mults) else 0 or 0)
            except Exception:
                mult = 0
            try:
                bid = int(brawlers[i] if i < len(brawlers) else 0 or 0)
            except Exception:
                bid = 0
            try:
                sid = int(skins[i] if i < len(skins) else 0 or 0)
            except Exception:
                sid = 0
            items.append({"ID": iid, "Multiplier": mult, "BrawlerID": bid, "SkinID": sid})
        return items

    def UpdateOfferData(self, i):
        if not hasattr(self, "offer_sources"):
            Shop.loadOffers(self)
        if int(i) < 0 or int(i) >= len(getattr(self, "offer_sources", [])):
            with open("JSON/offers.json", "r", encoding="utf-8") as f:
                data = json.load(f)
            data[str(i)]["WhoBuyed"].append(int(self.player.low_id))
            with open("JSON/offers.json", "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            return
        source, key = self.offer_sources[int(i)]
        low_id = int(self.player.low_id)
        if source == "daily":
            path = os.path.join("JSON", "daily_offers", str(low_id) + ".json")
            data = Shop.LoadJson(self, path, {})
            offers = data.get("offers") or []
            idx = int(key)
            if 0 <= idx < len(offers) and isinstance(offers[idx], dict):
                who = offers[idx].setdefault("WhoBuyed", [])
                if low_id not in who and str(low_id) not in who:
                    who.append(low_id)
                Shop.SaveJson(self, path, data)
            return
        if source == "community":
            data = Shop.CommunityProgress(self)
            pid = str(low_id)
            used = data.setdefault("claimedRewards", {}).setdefault(pid, [])
            rid = int(key)
            if rid not in used and str(rid) not in used:
                used.append(rid)
                Shop.SaveJson(self, "JSON/community_event.json", data)
            return
        with open("JSON/offers.json", "r", encoding="utf-8") as f:
            data = json.load(f)
        data[str(key)]["WhoBuyed"].append(low_id)
        with open("JSON/offers.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def RemoveOffer(self, i):
        with open("JSON/offers.json", "r") as f:
            data = json.load(f)
        data.pop(str(i), None)
        with open("JSON/offers.json", "w") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def LoadJson(self, path, default):
        try:
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return default

    def SaveJson(self, path, data):
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def CommunityConfig(self):
        return (Shop.LoadJson(self, "config.json", {}) or {}).get("CommunityEvent") or {}

    def CommunityProgress(self):
        data = Shop.LoadJson(self, "JSON/community_event.json", {"totalBattles": 0, "claimedRewards": {}, "skinsFor": {}})
        if not isinstance(data.get("claimedRewards"), dict):
            data["claimedRewards"] = {}
        if not isinstance(data.get("skinsFor"), dict):
            data["skinsFor"] = {}
        if not isinstance(data.get("pendingBoxes"), dict):
            data["pendingBoxes"] = {}
        data["totalBattles"] = int(data.get("totalBattles") or 0)
        return data

    def AddPendingBoxes(self, boxdid, extra):
        extra = int(extra or 0)
        if extra <= 0:
            return
        data = Shop.CommunityProgress(self)
        pid = str(int(self.player.low_id))
        pending = data.setdefault("pendingBoxes", {}).setdefault(pid, {})
        key = str(int(boxdid))
        pending[key] = int(pending.get(key) or 0) + extra
        Shop.SaveJson(self, "JSON/community_event.json", data)

    def TakePendingBox(self, boxdid):
        data = Shop.CommunityProgress(self)
        pid = str(int(self.player.low_id))
        pending = data.setdefault("pendingBoxes", {}).setdefault(pid, {})
        key = str(int(boxdid))
        n = int(pending.get(key) or 0)
        if n <= 0:
            return False
        pending[key] = n - 1
        Shop.SaveJson(self, "JSON/community_event.json", data)
        return True

    def AddCommunityBattle(self):
        cfg = Shop.CommunityConfig(self)
        if not cfg.get("Active"):
            return
        data = Shop.CommunityProgress(self)
        data["totalBattles"] = int(data.get("totalBattles") or 0) + 1
        Shop.SaveJson(self, "JSON/community_event.json", data)

    def LoadCommunityOffers(self):
        cfg = Shop.CommunityConfig(self)
        if not cfg.get("Active"):
            return []
        player = getattr(self, "player", None)
        if player is None:
            return []
        progress = Shop.CommunityProgress(self)
        battles = int(progress.get("totalBattles") or 0)
        used = progress.get("claimedRewards", {}).get(str(int(player.low_id))) or []
        claimed = set()
        for x in used:
            try:
                claimed.add(int(x))
            except Exception:
                continue
        owned_skins = set()
        unlocked = getattr(player, "UnlockedSkins", {}) or {}
        if isinstance(unlocked, dict):
            for sid, state in unlocked.items():
                try:
                    if int(state) == 1:
                        owned_skins.add(int(sid))
                except Exception:
                    continue
        types = {
            "big_box": (14, "offer_boxes"),
            "mega_box": (10, "offer_boxes"),
            "gems": (16, "offer_gems"),
            "coins": (1, "offer_coins"),
            "box": (6, "offer_boxes"),
            "skin": (4, "offer_special"),
        }
        out = []
        seen = set()
        for rw in cfg.get("Rewards") or []:
            try:
                rid = int(rw.get("id"))
                need = int(rw.get("battlesNeeded") or 0)
            except Exception:
                continue
            if rid in seen:
                continue
            if battles < need:
                continue
            seen.add(rid)
            rtype = str(rw.get("type") or "")
            if rtype == "skin":
                pool = []
                for s in rw.get("skins") or []:
                    try:
                        pool.append({"skinId": int(s.get("skinId")), "brawlerId": int(s.get("brawlerId"))})
                    except Exception:
                        continue
                available = [s for s in pool if s["skinId"] not in owned_skins]
                if not available:
                    if rid not in claimed:
                        continue
                    available = pool
                low = str(int(player.low_id))
                saved = (progress.get("skinsFor") or {}).get(low)
                chosen = None
                if isinstance(saved, dict):
                    try:
                        sid = int(saved.get("skinId"))
                        bid = int(saved.get("brawlerId"))
                        for s in available:
                            if s["skinId"] == sid and s["brawlerId"] == bid:
                                chosen = s
                                break
                    except Exception:
                        chosen = None
                if chosen is None:
                    chosen = random.choice(available)
                    progress.setdefault("skinsFor", {})[low] = chosen
                    Shop.SaveJson(self, "JSON/community_event.json", progress)
                sid = int(chosen["skinId"])
                bid = int(chosen["brawlerId"])
                offer = Shop._CommunityOffer(self, 3, 1, bid, 0, "offer_special")
                offer["ID"] = [3, 4, 0]
                offer["BrawlerID"] = [bid, bid, 0]
                offer["SkinID"] = [0, sid, 0]
                offer["Multiplier"] = [1, 1, 0]
                offer["CommunityRewardId"] = rid
                if rid in claimed:
                    offer["WhoBuyed"] = [int(player.low_id)]
                out.append(offer)
                continue
            if rtype not in types:
                continue
            shop_id, bgr = types[rtype]
            amount = max(1, int(rw.get("amount") or 1))
            offer = Shop._CommunityOffer(self, shop_id, amount, 0, 0, bgr)
            offer["CommunityRewardId"] = rid
            if rid in claimed:
                offer["WhoBuyed"] = [int(player.low_id)]
            out.append(offer)
        return out

    def _CommunityOffer(self, item_id, amount, brawler, skin, bgr):
        return {
            "ID": [int(item_id), 0, 0],
            "OfferTitle": "Community Event Reward",
            "SkinID": [int(skin), 0, 0],
            "Cost": 0,
            "OldCost": 0,
            "Multiplier": [int(amount), 0, 0],
            "BrawlerID": [int(brawler), 0, 0],
            "OfferView": 0,
            "ETType": 0,
            "ETMultiplier": 0,
            "Timer": 999999,
            "OfferBGR": bgr,
            "ShopType": 0,
            "ShopDisplay": 0,
            "WhoBuyed": [],
        }

    def MarkAllOffersViewed(self):
        data = Shop.LoadJson(self, "JSON/offers.json", {})
        changed = False
        if isinstance(data, dict):
            for offer in data.values():
                if isinstance(offer, dict) and offer.get("OfferView") != 2:
                    offer["OfferView"] = 2
                    changed = True
        if changed:
            Shop.SaveJson(self, "JSON/offers.json", data)

    def EncodeShopOffers(self):
        Shop.loadOffers(self)
        wow = self.offers
        count = len(wow)
        self.writeVint(count)
        for i in range(count):
            item = wow[i]
            if item['ID'][0] != 0 and item['ID'][1] != 0 and item['ID'][2] != 0:
                self.writeVint(3)
                self.writeVint(item['ID'][0])
                self.writeVint(item['Multiplier'][0])
                self.writeScId(16, item['BrawlerID'][0])
                self.writeVint(item['SkinID'][0])
                self.writeVint(item['ID'][1])
                self.writeVint(item['Multiplier'][1])
                self.writeScId(16, item['BrawlerID'][1])
                self.writeVint(item['SkinID'][1])
                self.writeVint(item['ID'][2])
                self.writeVint(item['Multiplier'][2])
                self.writeScId(16, item['BrawlerID'][2])
                self.writeVint(item['SkinID'][2])

            elif item['ID'][0] != 0 and item['ID'][1] != 0:
                self.writeVint(2)
                self.writeVint(item['ID'][0])
                self.writeVint(item['Multiplier'][0])
                self.writeScId(16, item['BrawlerID'][0])
                self.writeVint(item['SkinID'][0])
                self.writeVint(item['ID'][1])
                self.writeVint(item['Multiplier'][1])
                self.writeScId(16, item['BrawlerID'][1])
                self.writeVint(item['SkinID'][1])

            else:
                brawler_id = int(item['BrawlerID'][0])
                unlocked = int(self.player.UnlockedBrawlers.get(str(brawler_id), 1) or 0) == 1
                if brawler_id == 0 or unlocked:
                    self.writeVint(1)
                    self.writeVint(item['ID'][0])
                    self.writeVint(item['Multiplier'][0])
                    self.writeScId(16, item['BrawlerID'][0])
                    self.writeVint(item['SkinID'][0])
                else:
                    self.writeVint(1)
                    self.writeVint(1)
                    self.writeVint(0)
                    self.writeScId(16, 0)
                    self.writeVint(0)

            self.writeVint(item['ShopType'])

            self.writeVint(item['Cost'])
            self.writeVint(item['Timer'])

            self.writeVint(item['OfferView'])
            self.writeVint(100)
            who = item.get("WhoBuyed") or []
            already = False
            try:
                already = int(self.player.low_id) in [int(x) for x in who]
            except Exception:
                already = self.player.low_id in who
            bid0 = int(item['BrawlerID'][0])
            locked = bid0 != 0 and int(self.player.UnlockedBrawlers.get(str(bid0), 1) or 0) == 0
            if item.get("CommunityRewardId") is not None:
                locked = False
            self.writeBoolean(True if already or locked else False)

            self.writeBoolean(False)
            if locked:
                self.writeVint(0)
            else:
                self.writeVint(item['ShopDisplay'])
            self.writeVint(item['OldCost'])#oldCost
            self.writeVint(0)

            self.writeInt(0)
            self.write_string_reference(item['OfferTitle'])
            self.writeBoolean(False)
            self.writeString(item['OfferBGR'])
            self.writeVint(0)
            self.writeBoolean(False)
            self.writeVint(item['ETType']) # Extra Text Type | 1 = Factor(?x),
            self.writeVint(item['ETMultiplier']) # Extra Text
		#shopend
