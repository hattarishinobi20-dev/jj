from Logic.Commands.Client.LogicBoxDataCommand import LogicBoxDataCommand
from Utils.Reader import BSMessageReader
from Logic.Shop import Shop
from Logic.PinPack import PinPack
from Logic.Pin import Pin
from Logic.LogicBuy import LogicBuy
from database.DataBase import DataBase
from Utils.Fingerprint import Fingerprint
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards
from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd as Supply
class LogicPurchaseOfferCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.offer_index = self.read_Vint()


    def process(self):
        Shop.LoadOffers(self)
        if self.offer_index < 0 or self.offer_index >= len(self.offers):
            from Logic.Commands.Client.LogicOffersChangedCommand import LogicOffersChangedCommand
            LogicOffersChangedCommand(self.client, self.player).send()
            return
        offers = self.offers
        offer = offers[self.offer_index]
        who = offer.get("WhoBuyed") or []
        try:
            already = int(self.player.low_id) in [int(x) for x in who]
        except Exception:
            already = self.player.low_id in who
        if already:
            from Logic.Commands.Client.LogicOffersChangedCommand import LogicOffersChangedCommand
            LogicOffersChangedCommand(self.client, self.player).send()
            return
        id1 = offers[self.offer_index]['ID'][0]
        id2 = offers[self.offer_index]['ID'][1]
        id3 = offers[self.offer_index]['ID'][2]
        multi1 = offers[self.offer_index]['Multiplier'][0]
        multi2 = offers[self.offer_index]['Multiplier'][1]
        multi3 = offers[self.offer_index]['Multiplier'][2]
        brawler1 = offers[self.offer_index]['BrawlerID'][0]
        brawler2 = offers[self.offer_index]['BrawlerID'][1]
        brawler3 = offers[self.offer_index]['BrawlerID'][2]
        skin1 = offers[self.offer_index]['SkinID'][0]
        skin2 = offers[self.offer_index]['SkinID'][1]
        skin3 = offers[self.offer_index]['SkinID'][2]

        ID1 = 0
        ID2 = 0
        ID3 = 0


        if id1 == 1:
            ID1 = 1
        if id2 == 1:
            ID2 = 1
        if id3 == 1:
            ID3 = 1
        if id1 == 24:
            ID1 = 7
        if id2 == 24:
            ID2 = 7
        if id3 == 24:
            ID3 = 7            
        if id1 == 16:
            ID1 = 2
        if id2 == 16:
            ID2 = 2
        if id3 == 16:
            ID3 = 2
        if id1 == 5:
            ID1 = 3
        if id2 == 5:
            ID2 = 3
        if id3 == 5:
            ID3 = 3
        if id1 == 19:
            ID1 = 8 
        if id2 == 19:
            ID2 = 8 
        if id3 == 19:
            ID3 = 8 
        if id1 == 9:
            ID1 = 4
        if id2 == 9:
            ID2 = 4
        if id3 == 9:
            ID3 = 4
        if id1 == 8:
            ID1 = 5
        if id2 == 8:
            ID2 = 5
        if id3 == 8:
            ID3 = 5
        if id1 == 3:
            ID1 = 6
        if id2 == 3:
            ID2 = 6
        if id3 == 3:
            ID3 = 6

        if id1 == 4:
            ID1 = 7
        if id2 == 4:
            ID2 = 7
        if id3 == 4:
            ID3 = 7
            
        if id1 == 21:
            PinPack(self.client, self.player).send()
            Shop.UpdateOfferData(self, self.offer_index)
        if id1 == 19:
            self.pin = skin1
            pin = skin1
            Pin(self.client, self.player, pin).send()
            ID1 = 8 
            Shop.UpdateOfferData(self, self.offer_index)
        if id2 == 19:
            self.pin = skin2
            pin = skin2
            Pin(self.client, self.player, pin).send()
            ID1 = 8 
            Shop.UpdateOfferData(self, self.offer_index)
        if id3 == 19:
            self.pin = skin3
            pin = skin3
            Pin(self.client, self.player, pin).send()
            ID1 = 8 
            Shop.UpdateOfferData(self, self.offer_index)
            
        if id1 == 8 or id2 == 8 or id3 == 8:
            for i, (brawler_id, multiplier) in enumerate(zip([brawler1, brawler2, brawler3], [multi1, multi2, multi3])):
                if brawler_id != 0:
                    current_points = self.player.brawlerPoints.get(str(brawler_id), 0)
                    new_points = current_points + multiplier
                    self.player.brawlerPoints[str(brawler_id)] = new_points
                    dbupd = 'brawlerPoints'
                    DataBase.replaceValue(self, dbupd, self.player.brawlerPoints)
                    
            
        box_map = {6: 10, 10: 11, 14: 12}
        if id1 in box_map:
            from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd as Supply
            times = max(1, int(multi1 or 1))
            Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": box_map[id1], "Count": times}).send()
            Shop.UpdateOfferData(self, self.offer_index)
        else:
            if id1 != 0 and id2 != 0 and id3 != 0:
                LogicBuy(self.client, self.player, ID1, ID2, ID3, multi1, multi2, multi3, brawler1, brawler2, brawler3, skin1, skin2, skin3).send()
                Shop.UpdateOfferData(self, self.offer_index)
            elif id1 != 0 and id2 != 0:
                LogicBuy(self.client, self.player, ID1, ID2, 0, multi1, multi2, 0, brawler1, brawler2, 0, skin1, skin2, 0).send()
                Shop.UpdateOfferData(self, self.offer_index)
            else:
                LogicBuy(self.client, self.player, ID1, 0, 0, multi1, 0, 0, brawler1, 0, 0, skin1, 0, 0).send()
                Shop.UpdateOfferData(self, self.offer_index)
                
            if offers[self.offer_index]['ShopType']==0:
                self.player.gems -= offers[self.offer_index]['Cost']
                dbupd = 'gems'
                DataBase.replaceValue(self, dbupd, self.player.gems)
            elif offers[self.offer_index]['ShopType']==1:
                self.player.gold -= offers[self.offer_index]['Cost']
                dbupd = 'gold'
                DataBase.replaceValue(self, dbupd, self.player.gold)
            elif offers[self.offer_index]['ShopType']==2:
                self.player.starpoints -= offers[self.offer_index]['Cost']
                dbupd = 'starpoints'
                DataBase.replaceValue(self, dbupd, self.player.starpoints)
