import json
import os
import time
import threading

LOCK = threading.Lock()
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PATH = os.path.join(ROOT, "JSON", "store_pending.json")


def _load():
    if not os.path.exists(PATH):
        return {}
    try:
        with open(PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save(data):
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    with open(PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def add_pending(low_id, gems):
    gems = int(gems)
    if gems <= 0:
        return
    with LOCK:
        data = _load()
        key = str(int(low_id))
        data.setdefault(key, []).append({"gems": gems, "ts": int(time.time())})
        _save(data)


def pop_pending(low_id):
    with LOCK:
        data = _load()
        key = str(int(low_id))
        items = data.pop(key, [])
        _save(data)
        return items
