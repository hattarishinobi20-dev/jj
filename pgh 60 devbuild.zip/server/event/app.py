import os
import json
import logging
import traceback
from datetime import datetime
from flask import Flask, jsonify, render_template
from werkzeug.exceptions import HTTPException

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__))
ERROR_FILE = os.path.join(ROOT, "event_errors.txt")
CONFIG = os.path.join(ROOT, "config.json")
PROGRESS = os.path.join(ROOT, "JSON", "community_event.json")

TYPE_IMG = {
    "big_box": "bigbox.png",
    "mega_box": "megabox.png",
    "gems": "gems.png",
    "coins": "coins.png",
    "box": "brawlbox.webp",
    "skin": "skin.webp",
}

logging.getLogger("werkzeug").disabled = True
logging.getLogger("werkzeug").setLevel(logging.CRITICAL)

app = Flask(
    __name__,
    template_folder=os.path.join(HERE, "templates"),
    static_folder=os.path.join(HERE, "static"),
)
app.logger.disabled = True


def write_error(err):
    try:
        with open(ERROR_FILE, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), err))
            f.write(traceback.format_exc())
            f.write("\n")
    except Exception:
        pass


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


@app.after_request
def no_store(resp):
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


@app.route("/")
def home():
    return render_template("event.html")


@app.route("/api/progress")
def api_progress():
    cfg = (read_json(CONFIG, {}) or {}).get("CommunityEvent") or {}
    prog = read_json(PROGRESS, {"totalBattles": 0}) or {}
    active = bool(cfg.get("Active"))
    limit = max(1, int(cfg.get("BattlesLimit") or 1))
    battles = int(prog.get("totalBattles") or 0) if active else 0
    pct = min(100.0, 100.0 * battles / limit) if active else 0.0
    rewards = []
    for rw in cfg.get("Rewards") or []:
        try:
            rid = int(rw.get("id"))
            need = int(rw.get("battlesNeeded") or 0)
        except Exception:
            continue
        rtype = str(rw.get("type") or "")
        rewards.append({
            "n": rid,
            "title": rtype,
            "img": TYPE_IMG.get(rtype, ""),
            "unlocked": bool(active and battles >= need),
            "need": need,
            "amount": int(rw.get("amount") or 1),
        })
    return jsonify({
        "ok": True,
        "active": active,
        "battles": battles,
        "limit": limit,
        "percent": pct,
        "rewards": rewards,
    })


@app.errorhandler(Exception)
def on_error(err):
    if isinstance(err, HTTPException):
        return err
    write_error(err)
    return jsonify({"ok": False, "error": "Server error"}), 500


if __name__ == "__main__":
    try:
        import flask.cli
        flask.cli.show_server_banner = lambda *a, **k: None
    except Exception:
        pass
    try:
        app.run(host="0.0.0.0", port=8084, debug=False, threaded=True, use_reloader=False)
    except Exception as e:
        write_error(e)
