import os
import re
import csv
import json
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
OFFERS_FILE = os.path.join(ROOT, "JSON", "site_offers.json")
UPLOAD_DIR = os.path.join(ROOT, "site", "static", "offers")

BRAWLERS = [
    {"id": 0, "name": "SHELLY"}, {"id": 1, "name": "COLT"}, {"id": 2, "name": "BULL"},
    {"id": 3, "name": "BROCK"}, {"id": 4, "name": "RICO"}, {"id": 5, "name": "SPIKE"},
    {"id": 6, "name": "BARLEY"}, {"id": 7, "name": "JESSIE"}, {"id": 8, "name": "NITA"},
    {"id": 9, "name": "DYNAMIKE"}, {"id": 10, "name": "EL PRIMO"}, {"id": 11, "name": "MORTIS"},
    {"id": 12, "name": "CROW"}, {"id": 13, "name": "POCO"}, {"id": 14, "name": "BO"},
    {"id": 15, "name": "PIPER"}, {"id": 16, "name": "PAM"}, {"id": 17, "name": "TARA"},
    {"id": 18, "name": "DARRYL"}, {"id": 19, "name": "PENNY"}, {"id": 20, "name": "FRANK"},
    {"id": 21, "name": "GENE"}, {"id": 22, "name": "TICK"}, {"id": 23, "name": "LEON"},
    {"id": 24, "name": "ROSA"}, {"id": 25, "name": "CARL"}, {"id": 26, "name": "BIBI"},
    {"id": 27, "name": "8-BIT"}, {"id": 28, "name": "SANDY"}, {"id": 29, "name": "BEA"},
    {"id": 30, "name": "EMZ"}, {"id": 31, "name": "MR. P"}, {"id": 32, "name": "MAX"},
    {"id": 34, "name": "JACKY"}, {"id": 35, "name": "GALE"}, {"id": 36, "name": "NANI"},
    {"id": 37, "name": "SPROUT"}, {"id": 38, "name": "SURGE"}, {"id": 39, "name": "COLETTE"},
]

PATTERNS = [
    {"id": "store-yellow", "name": "Store yellow", "css": "#f5c400"},
    {"id": "store-purple", "name": "Store purple", "css": "#1b1030"},
    {"id": "topbar", "name": "Topbar", "css": "#f5c400 url('/static/img/topbar-bg-YCNPOBYK.png') center / cover"},
    {"id": "rays", "name": "Rays", "css": "#5b21b6 url('/static/img/rays-ITM5HKZQ.png') center / cover"},
    {"id": "pack-purple", "name": "Pack purple", "css": "linear-gradient(180deg, #c84bff 0%, #7a1cc7 55%, #4a0e86 100%)"},
    {"id": "pack-blue", "name": "Pack blue", "css": "linear-gradient(180deg, #5ad0ff 0%, #2a6bff 60%, #1a3cb8 100%)"},
    {"id": "pack-gold", "name": "Pack gold", "css": "linear-gradient(180deg, #ffd84a 0%, #ff8a1a 50%, #d13a00 100%)"},
    {"id": "pack-pink", "name": "Chromatic", "css": "linear-gradient(180deg, #ff6b9d 0%, #c9184a 100%)"},
]

GALLERY = [
    {"id": "g1", "name": "Night stars", "file": "gallery/g1.svg"},
    {"id": "g2", "name": "Gem field", "file": "gallery/g2.svg"},
    {"id": "g3", "name": "Arcade", "file": "gallery/g3.svg"},
    {"id": "g4", "name": "Desert", "file": "gallery/g4.svg"},
    {"id": "g5", "name": "Ice", "file": "gallery/g5.svg"},
]


def _pretty(name):
    name = re.sub(r"Default$", "", name or "")
    name = re.sub(r"([a-z])([A-Z])", r"\1 \2", name)
    name = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", name)
    return name.replace("_", " ").strip() or "Skin"


def load_skin_catalog():
    skins_path = os.path.join(ROOT, "GameAssets", "csv_logic", "skins.csv")
    confs_path = os.path.join(ROOT, "GameAssets", "csv_logic", "skin_confs.csv")
    chars_path = os.path.join(ROOT, "GameAssets", "csv_logic", "characters.csv")
    catalog = []
    if not os.path.exists(skins_path):
        return catalog
    def rows(path):
        with open(path, encoding="utf-8", errors="replace") as f:
            return list(csv.reader(f))
    skins = rows(skins_path)
    confs = {}
    if os.path.exists(confs_path):
        cr = rows(confs_path)
        for row in cr[2:]:
            if row and row[0]:
                confs[row[0]] = row[1] if len(row) > 1 else ""
    char_item = {}
    if os.path.exists(chars_path):
        ch = rows(chars_path)
        for row in ch[2:]:
            if row and row[0]:
                char_item[row[0]] = (row[3] if len(row) > 3 else "").lower()
    item_to_bid = {}
    for b in BRAWLERS:
        key = b["name"].lower().replace(".", "").replace(" ", "")
        item_to_bid[key] = b
        item_to_bid[b["name"].lower()] = b
    extra = {
        "shelly": 0, "colt": 1, "bull": 2, "brock": 3, "rico": 4, "spike": 5,
        "barley": 6, "jessie": 7, "nita": 8, "dynamike": 9, "primo": 10,
        "elprimo": 10, "mortis": 11, "crow": 12, "poco": 13, "bo": 14,
        "piper": 15, "pam": 16, "tara": 17, "darryl": 18, "penny": 19,
        "frank": 20, "gene": 21, "tick": 22, "leon": 23, "rosa": 24,
        "carl": 25, "bibi": 26, "8bit": 27, "8-bit": 27, "sandy": 28,
        "bea": 29, "emz": 30, "mrp": 31, "mr. p": 31, "max": 32,
        "jacky": 34, "gale": 35, "nani": 36, "sprout": 37, "surge": 38,
        "colette": 39,
    }
    bid_by_id = {b["id"]: b for b in BRAWLERS}
    header = skins[0]
    try:
        conf_i = header.index("Conf")
    except ValueError:
        conf_i = 1
    try:
        gems_i = header.index("CostGems")
    except ValueError:
        gems_i = 8
    for i, row in enumerate(skins[2:]):
        if not row or not row[0]:
            continue
        conf = row[conf_i] if len(row) > conf_i else ""
        char = confs.get(conf, "")
        item = char_item.get(char, "")
        key = re.sub(r"[^a-z0-9]", "", (item or "").lower())
        brawler = None
        if key in extra:
            brawler = bid_by_id.get(extra[key])
        if brawler is None:
            for b in BRAWLERS:
                if b["name"].lower().replace(" ", "") in key or key in b["name"].lower():
                    brawler = b
                    break
        cost = 0
        try:
            cost = int(row[gems_i] or 0)
        except (TypeError, ValueError, IndexError):
            cost = 0
        catalog.append({
            "id": i,
            "key": row[0],
            "name": _pretty(row[0]),
            "brawler_id": brawler["id"] if brawler else 0,
            "brawler": brawler["name"] if brawler else "",
            "cost": cost,
        })
    return catalog


SKINS = load_skin_catalog()
SKIN_BY_ID = {s["id"]: s for s in SKINS}


def ensure_files():
    os.makedirs(os.path.dirname(OFFERS_FILE), exist_ok=True)
    os.makedirs(os.path.join(UPLOAD_DIR, "gallery"), exist_ok=True)
    if not os.path.exists(OFFERS_FILE):
        with open(OFFERS_FILE, "w", encoding="utf-8") as f:
            json.dump({"next_id": 1, "offers": []}, f)


def load_data():
    ensure_files()
    with open(OFFERS_FILE, encoding="utf-8") as f:
        data = json.load(f)
    if "offers" not in data:
        data = {"next_id": 1, "offers": []}
    return data


def save_data(data):
    ensure_files()
    tmp = OFFERS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, OFFERS_FILE)


def bg_css(offer, media_prefix="/static/offers"):
    kind = offer.get("bg_kind") or "pattern"
    value = offer.get("bg_value") or "pack-purple"
    if kind == "pattern":
        for p in PATTERNS:
            if p["id"] == value:
                return p["css"]
        return PATTERNS[4]["css"]
    if kind == "gallery":
        for g in GALLERY:
            if g["id"] == value:
                return f"url('{media_prefix}/{g['file']}') center / cover"
        return PATTERNS[4]["css"]
    if kind == "gif" and value:
        return f"url('{media_prefix}/{value}') center / cover"
    return PATTERNS[4]["css"]


def photo_url(offer, media_prefix="/static/offers"):
    photo = offer.get("photo") or ""
    if photo:
        return f"{media_prefix}/{photo}"
    return ""


def public_offer(offer, media_prefix="/static/offers"):
    gems = int(offer.get("gems") or 0)
    old = int(offer.get("old_gems") or 0)
    return {
        "id": offer["id"],
        "name": offer.get("name") or "Skin",
        "type": offer.get("type") or "Skin",
        "skin_id": int(offer.get("skin_id") or 0),
        "brawler_id": int(offer.get("brawler_id") or 0),
        "brawler": offer.get("brawler") or "",
        "gems": gems,
        "old_gems": old if old > gems else 0,
        "discount": bool(old > gems),
        "photo": photo_url(offer, media_prefix),
        "background": bg_css(offer, media_prefix),
        "bg_kind": offer.get("bg_kind") or "pattern",
        "bg_value": offer.get("bg_value") or "",
        "active": bool(offer.get("active", True)),
        "created_at": offer.get("created_at") or 0,
        "updated_at": offer.get("updated_at") or 0,
    }


def list_offers(active_only=False):
    data = load_data()
    out = []
    for o in data["offers"]:
        if active_only and not o.get("active", True):
            continue
        out.append(public_offer(o))
    return out


def get_offer(oid):
    data = load_data()
    for o in data["offers"]:
        if int(o["id"]) == int(oid):
            return o
    return None


def upsert_offer(payload, existing_id=None):
    data = load_data()
    now = int(time.time())
    if existing_id is not None:
        for o in data["offers"]:
            if int(o["id"]) == int(existing_id):
                prev_gems = int(o.get("gems") or 0)
                new_gems = int(payload.get("gems") or 0)
                old_gems = int(payload.get("old_gems") or 0)
                if new_gems < prev_gems and old_gems <= 0:
                    old_gems = prev_gems
                o.update({
                    "name": payload.get("name") or o.get("name") or "Skin",
                    "type": "Skin",
                    "skin_id": int(payload.get("skin_id") or 0),
                    "brawler_id": int(payload.get("brawler_id") or 0),
                    "brawler": payload.get("brawler") or "",
                    "gems": new_gems,
                    "old_gems": old_gems,
                    "photo": payload.get("photo", o.get("photo") or ""),
                    "bg_kind": payload.get("bg_kind") or o.get("bg_kind") or "pattern",
                    "bg_value": payload.get("bg_value") if payload.get("bg_value") is not None else o.get("bg_value"),
                    "active": bool(payload.get("active", o.get("active", True))),
                    "updated_at": now,
                })
                save_data(data)
                return o
        return None
    oid = int(data.get("next_id") or 1)
    data["next_id"] = oid + 1
    offer = {
        "id": oid,
        "name": payload.get("name") or "Skin",
        "type": "Skin",
        "skin_id": int(payload.get("skin_id") or 0),
        "brawler_id": int(payload.get("brawler_id") or 0),
        "brawler": payload.get("brawler") or "",
        "gems": int(payload.get("gems") or 0),
        "old_gems": int(payload.get("old_gems") or 0),
        "photo": payload.get("photo") or "",
        "bg_kind": payload.get("bg_kind") or "pattern",
        "bg_value": payload.get("bg_value") or "pack-purple",
        "active": bool(payload.get("active", True)),
        "created_at": now,
        "updated_at": now,
    }
    data["offers"].append(offer)
    save_data(data)
    return offer


def delete_offers(ids):
    data = load_data()
    ids = {int(i) for i in ids}
    data["offers"] = [o for o in data["offers"] if int(o["id"]) not in ids]
    save_data(data)


def clone_offers(ids):
    data = load_data()
    ids = {int(i) for i in ids}
    now = int(time.time())
    clones = []
    for o in list(data["offers"]):
        if int(o["id"]) in ids:
            nid = int(data.get("next_id") or 1)
            data["next_id"] = nid + 1
            c = dict(o)
            c["id"] = nid
            c["name"] = (o.get("name") or "Skin") + " copy"
            c["active"] = False
            c["created_at"] = now
            c["updated_at"] = now
            data["offers"].append(c)
            clones.append(c)
    save_data(data)
    return clones
